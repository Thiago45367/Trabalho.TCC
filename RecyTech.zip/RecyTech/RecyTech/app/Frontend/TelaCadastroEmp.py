# tela_cadastro_empresa.py
from kivy.app import App
from kivy.uix.boxlayout import BoxLayout
from kivy.lang import Builder
from kivy.metrics import dp, sp
from kivy.uix.popup import Popup
from kivy.uix.label import Label
from kivy.uix.button import Button

# Import do backend específico para Empresa
from app.Backend.Controle.ControleEmp import ControleEmp

# KV em string para manter organizado
interface_TelaCadastroEmpresa = '''
<TelaCadastroEmp>:
    orientation: 'vertical'
    padding: dp(12)
    spacing: dp(6)

    canvas.before:
        Color:
            rgba: 0.5, 0.5, 0.5, 1
        Rectangle:
            pos: self.pos
            size: self.size

    # LOGO
    Label:
        text: '[b]Recy[color=00FF00]Tech[/color][/b]'
        markup: True
        font_size: sp(28)
        size_hint_y: None
        height: self.texture_size[1] + dp(6)
        halign: 'center'
        valign: 'middle'
        text_size: self.width, None

    Widget:
        size_hint_y: None
        height: dp(6)

    AnchorLayout:
        anchor_x: 'center'
        size_hint_y: None
        height: painel.height  

        BoxLayout:
            id: painel
            orientation: 'vertical'
            size_hint_x: 0.9
            size_hint_y: None
            height: self.minimum_height
            padding: dp(10)
            spacing: dp(8)

            canvas.before:
                Color:
                    rgba: 0.2, 0.2, 0.2, 1
                RoundedRectangle:
                    pos: self.pos
                    size: self.size
                    radius: [dp(6)]

            # Abas Usuário/Empresa
            BoxLayout:
                size_hint_y: None
                height: dp(40)
                spacing: dp(8)

                ToggleButton:
                    text: 'Usuário'
                    group: 'tipo'
                    background_normal: ''
                    background_color: 0.75, 0.75, 0.75, 1
                    color: 0,0,0,1
                    font_size: sp(14)

                ToggleButton:
                    text: 'Empresa'
                    group: 'tipo'
                    state: 'down'
                    background_normal: ''
                    background_color: 0.12, 0.45, 0.80, 1
                    color: 1,1,1,1
                    font_size: sp(14)

            # ===== CAMPOS =====
            # Email
            BoxLayout:
                orientation: 'vertical'
                size_hint_y: None
                height: dp(60)

                Label:
                    text: 'Email'
                    color: 1,1,1,1
                    size_hint_y: None
                    height: dp(16)
                    font_size: sp(12)

                TextInput:
                    id: email
                    hint_text: 'Digite o email da empresa'
                    multiline: False
                    size_hint_y: None
                    height: dp(36)
                    font_size: sp(14)

            # Senha
            BoxLayout:
                orientation: 'vertical'
                size_hint_y: None
                height: dp(60)

                Label:
                    text: 'Senha'
                    color: 1,1,1,1
                    size_hint_y: None
                    height: dp(16)
                    font_size: sp(12)

                TextInput:
                    id: senha
                    hint_text: 'Senha'
                    password: True
                    multiline: False
                    size_hint_y: None
                    height: dp(36)
                    font_size: sp(14)

            # Confirmar Senha
            BoxLayout:
                orientation: 'vertical'
                size_hint_y: None
                height: dp(60)

                Label:
                    text: 'Confirmar Senha'
                    color: 1,1,1,1
                    size_hint_y: None
                    height: dp(16)
                    font_size: sp(12)

                TextInput:
                    id: confirmar
                    hint_text: 'Confirmar senha'
                    password: True
                    multiline: False
                    size_hint_y: None
                    height: dp(36)
                    font_size: sp(14)

            # CNPJ
            BoxLayout:
                orientation: 'vertical'
                size_hint_y: None
                height: dp(60)

                Label:
                    text: 'CNPJ'
                    color: 1,1,1,1
                    size_hint_y: None
                    height: dp(16)
                    font_size: sp(12)

                TextInput:
                    id: cnpj
                    hint_text: 'Digite o CNPJ da empresa'
                    multiline: False
                    size_hint_y: None
                    height: dp(36)
                    font_size: sp(14)

    # Botão Cadastrar
    AnchorLayout:
        anchor_x: 'center'
        size_hint_y: None
        height: dp(50)

        Button:
            text: '[b]CADASTRAR[/b]'
            markup: True
            size_hint_x: 0.9
            height: dp(48)
            background_normal: ''
            background_color: 0, 0, 0, 0
            color: 1, 1, 1, 1
            font_size: sp(16)
            on_release: root.cadastrar()

            canvas.before:
                Color:
                    rgba: 0, 0, 0, 1
                RoundedRectangle:
                    pos: self.pos
                    size: self.size
                    radius: [dp(24)]

    # Link de voltar
    AnchorLayout:
        anchor_x: 'center'
        size_hint_y: None
        height: dp(28)

        Label:
            text: '[u]Voltar para o login[/u]'
            markup: True
            size_hint_x: 0.9
            halign: 'center'
            valign: 'middle'
            text_size: self.size
            font_size: sp(12)
'''

Builder.load_string(interface_TelaCadastroEmpresa)

class TelaCadastroEmp(BoxLayout):

    def cadastrar(self):
        email = self.ids.email.text
        senha = self.ids.senha.text
        confirmar = self.ids.confirmar.text
        cnpj = self.ids.cnpj.text

        def mostrar_alerta(msg):
            box = BoxLayout(orientation="vertical", spacing=10, padding=10)
            label = Label(text=msg, halign="center", valign="middle")
            btn = Button(text="OK", size_hint=(1, 0.3))
            box.add_widget(label)
            box.add_widget(btn)
            popup = Popup(title="Atenção", content=box, size_hint=(0.9, 0.4), auto_dismiss=False)
            btn.bind(on_release=popup.dismiss)
            popup.open()

        # Validações
        if not email.strip():
            mostrar_alerta("Preencha o campo de E-mail!")
            return
        if not senha.strip():
            mostrar_alerta("Preencha o campo de Senha!")
            return
        if not confirmar.strip():
            mostrar_alerta("Confirme sua senha!")
            return
        if not cnpj.strip():
            mostrar_alerta("Preencha o CNPJ!")
            return
        if senha != confirmar:
            mostrar_alerta("Senhas não coincidem!")
            return

        controle = ControleEmp()

        if controle.dao.existe_email(email):
            mostrar_alerta("Email já cadastrado!")
            return

        if controle.dao.existe_cnpj(cnpj):
            mostrar_alerta("CNPJ já cadastrado!")
            return

        sucesso = controle.cadastrar_empresa(email=email, senha=senha, cnpj=cnpj)

        if sucesso:
            mostrar_alerta("✅ Empresa cadastrada com sucesso!")
        else:
            mostrar_alerta("❌ Erro ao cadastrar empresa.")

class TelaCadastroEmpresaApp(App):
    def build(self):
        return TelaCadastroEmp()

if __name__ == "__main__":
    TelaCadastroEmpresaApp().run()
