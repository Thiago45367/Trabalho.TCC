from kivy.app import App
from kivy.uix.boxlayout import BoxLayout
from kivy.lang import Builder
from kivy.uix.behaviors import ButtonBehavior
from kivy.uix.image import Image


interface_TelaInicioUs = '''
<TelaInicialUsuario>:
    orientation: "vertical"
    # >>> REMOVIDO o padding que criava bordas verdes ao redor da barra
    padding: 0
    # pode manter um espacinho entre conteúdo e barra, só afeta verticalmente
    spacing: dp(8)

    canvas.before:
        Color:
            rgba: 0.4, 0.8, 0.4, 1  # fundo verde
        Rectangle:
            pos: self.pos
            size: self.size

    # ----- CONTEÚDO (com padding próprio) -----
    BoxLayout:
        orientation: "vertical"
        padding: dp(8)          # o respiro lateral e superior fica só no conteúdo
        spacing: dp(12)
        size_hint_y: 1

        # Área de postagens (scroll)
        ScrollView:
            do_scroll_x: False

            BoxLayout:
                id: feed
                orientation: "vertical"
                size_hint_y: None
                height: self.minimum_height
                spacing: dp(12)

                # Aqui os posts serão adicionados dinamicamente depois

    # ----- BARRA INFERIOR (cinza encostando nas bordas) -----
    BoxLayout:
        size_hint_y: None
        height: dp(70)
        spacing: dp(30)
        # padding interno da barra (não cria borda verde)
        padding: dp(10)

        canvas.before:
            Color:
                rgba: 0.5, 0.5, 0.5, 1  # cinza
            Rectangle:
                # ocupa toda a largura e vai até o fundo da janela
                pos: self.pos
                size: self.size

        # Aba Início
        BoxLayout:
            orientation: "vertical"
            spacing: dp(2)
            IconButton:
                source: "../Assets/Home.png"
                size_hint: None, None
                size: dp(50), dp(50)
                pos_hint: {"center_x": .5}
                on_press: app.ir_para_home()
            Label:
                text: "Início"
                font_size: sp(12)
                halign: "center"
                valign: "middle"
                text_size: self.size
                color: 0,0,0,1

        # Aba Reciclar
        BoxLayout:
            orientation: "vertical"
            spacing: dp(2)
            IconButton:
                source: "../Assets/Reciclagem.png"
                size_hint: None, None
                size: dp(60), dp(60)
                pos_hint: {"center_x": .5}
                on_press: app.ir_para_reciclar()
            Label:
                text: "Reciclar"
                font_size: sp(12)
                halign: "center"
                valign: "middle"
                text_size: self.size
                color: 0,0,0,1

        # Aba Notificações
        BoxLayout:
            orientation: "vertical"
            spacing: dp(2)
            IconButton:
                source: "../Assets/Notificacao.png"
                size_hint: None, None
                size: dp(50), dp(50)
                pos_hint: {"center_x": .5}
                on_press: app.ir_para_notificacoes()
            Label:
                text: "Notificações"
                font_size: sp(12)
                halign: "center"
                valign: "middle"
                text_size: self.size
                color: 0,0,0,1
'''

# 🔹 Botão que é um ícone
class IconButton(ButtonBehavior, Image):
    pass


class TelaInicialUsuario(BoxLayout):
    pass


class RecyTech(App):
    def build(self):
        Builder.load_string(interface_TelaInicioUs)
        return TelaInicialUsuario()

    def ir_para_home(self):
        print("👉 Ir para tela Home")

    def ir_para_reciclar(self):
        print("♻️ Ir para tela Reciclar")

    def ir_para_notificacoes(self):
        print("🔔 Ir para tela Notificações")


if __name__ == "__main__":
    RecyTech().run()
