from kivy.app import App
from kivy.uix.boxlayout import BoxLayout
from kivy.lang import Builder
from kivy.uix.behaviors import ButtonBehavior
from kivy.uix.image import Image

# Classe para transformar imagem em botão
class IconButton(ButtonBehavior, Image):
    pass

# Layout principal
class TelaMapaUsuario(BoxLayout):
    pass

# ----- KV embutido -----
interface_kv = '''
<TelaMapaUsuario>:
    orientation: "vertical"

    # Fundo geral verde claro
    canvas.before:
        Color:
            rgba: 0.4, 0.8, 0.4, 1
        Rectangle:
            pos: self.pos
            size: self.size

    # ----- ÁREA DO MAPA -----
    BoxLayout:
        size_hint_y: 0.6
        padding: dp(5)
        spacing: dp(5)
        canvas.before:
            Color:
                rgba: 1, 1, 1, 1
            Rectangle:
                pos: self.pos
                size: self.size

        Label:
            text: "[Mapa aparecerá aqui futuramente]"
            markup: True
            color: 0,0,0,1

    # ----- OPÇÕES (Filtros e SOS) -----
    BoxLayout:
        orientation: "vertical"
        padding: dp(10)
        spacing: dp(10)
        size_hint_y: 0.25

        canvas.before:
            Color:
                rgba: 0, 0.7, 0.2, 1   # Fundo verde da seção
            Rectangle:
                pos: self.pos
                size: self.size

        # Botão Filtrar Pontos de Coleta com ícone
        BoxLayout:
            orientation: "horizontal"
            size_hint_y: None
            height: dp(45)
            spacing: dp(10)

            Image:
                source: "../Assets/Funil.png"
                size_hint_x: None
                width: dp(30)

            Button:
                text: "Filtrar Pontos de Coletas"
                background_normal: ""  
                background_color: 0, 0, 0, 0   # transparente
                color: 0,0,0,1                 # texto preto
                halign: "left"
                valign: "middle"
                text_size: self.size
                on_press: app.filtrar_pontos()

        # Botão Ajuda SOS com ícone
        BoxLayout:
            orientation: "horizontal"
            size_hint_y: None
            height: dp(45)
            spacing: dp(10)

            Image:
                source: "../Assets/Help.png"
                size_hint_x: None
                width: dp(30)

            Button:
                text: "Ajuda SOS"
                background_normal: ""
                background_color: 0, 0, 0, 0   # transparente
                color: 1,0,0,1                 # texto vermelho
                halign: "left"
                valign: "middle"
                text_size: self.size
                on_press: app.pedir_ajuda()

    # ----- BARRA INFERIOR -----
    BoxLayout:
        size_hint_y: None
        height: dp(70)
        spacing: dp(30)
        padding: dp(10)

        canvas.before:
            Color:
                rgba: 0.5, 0.5, 0.5, 1
            Rectangle:
                pos: self.pos
                size: self.size

        # Aba Início
        BoxLayout:
            orientation: "vertical"
            spacing: dp(2)
            IconButton:
                source: "../Assets/Home.png"
                size_hint: None, None
                size: dp(40), dp(40)
                pos_hint: {"center_x": .5}
                on_press: app.ir_para_home()
            Label:
                text: "Início"
                font_size: sp(12)
                halign: "center"
                valign: "middle"
                text_size: self.size
                color: 0,0,0,1

        # Aba Reciclar (destaque central)
        BoxLayout:
            orientation: "vertical"
            spacing: dp(0)
            padding: [0, dp(5), 0, 0]  # sobe o ícone para alinhar
            IconButton:
                source: "../Assets/Reciclagem.png"
                size_hint: None, None
                size: dp(50), dp(50)
                pos_hint: {"center_x": .5}
                on_press: app.ir_para_reciclar()
            Label:
                text: "Reciclar"
                font_size: sp(12)
                halign: "center"
                valign: "middle"
                text_size: self.size
                color: 0,0,0,1

        # Aba Notificações
        BoxLayout:
            orientation: "vertical"
            spacing: dp(2)
            IconButton:
                source: "../Assets/Notificacao.png"
                size_hint: None, None
                size: dp(40), dp(40)
                pos_hint: {"center_x": .5}
                on_press: app.ir_para_notificacoes()
            Label:
                text: "Notificações"
                font_size: sp(12)
                halign: "center"
                valign: "middle"
                text_size: self.size
                color: 0,0,0,1
'''

# ----- APP PRINCIPAL -----
class RecyTechMapa(App):
    def build(self):
        Builder.load_string(interface_kv)
        return TelaMapaUsuario()

    # ----- Funções dos botões -----
    def filtrar_pontos(self):
        print("🔎 Filtrar pontos de coleta")

    def pedir_ajuda(self):
        print("🚨 Ajuda SOS acionada!")

    def ir_para_home(self):
        print("👉 Voltar para Home")

    def ir_para_reciclar(self):
        print("♻️ Ir para Reciclar")

    def ir_para_notificacoes(self):
        print("🔔 Ir para Notificações")

if __name__ == "__main__":
    RecyTechMapa().run()
