from kivy.app import App
from kivy.lang import Builder
from kivy.uix.behaviors import ButtonBehavior
from kivy.uix.image import Image
from kivy.uix.screenmanager import Screen
from kivy.uix.popup import Popup
from kivy.uix.label import Label
from kivy.uix.button import Button
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.widget import Widget
from kivy.metrics import dp, sp
from kivy.graphics import Color, RoundedRectangle

interface_TelaInicioEmp = '''
<HeaderEmpresa>:
    size_hint_y: None
    height: dp(55)
    padding: dp(10)
    spacing: dp(10)
    canvas.before:
        Color:
            rgba: 0.9, 0.9, 0.9, 1
        Rectangle:
            pos: self.pos
            size: self.size

    FotoPerfil:
        id: foto_perfil
        size_hint: None, None
        size: dp(38), dp(38)
        source: app.empresa_foto if app.empresa_foto else "app/Frontend/Assets/Foto_Perfil.png"

    Label:
        id: lbl_nome
        text: app.empresa_nome if app.empresa_nome else "Empresa"
        font_size: sp(16)
        color: 0,0,0,1
        halign: "left"
        valign: "middle"
        text_size: self.size

<TelaInicialEmpresa>:
    BoxLayout:
        orientation: "vertical"
        padding: 0
        spacing: dp(8)

        canvas.before:
            Color:
                rgba: 1, 1, 0.5, 1
            Rectangle:
                pos: self.pos
                size: self.size

        HeaderEmpresa:
            id: header

        BoxLayout:
            orientation: "vertical"
            padding: dp(8)
            spacing: dp(12)
            size_hint_y: 1

            ScrollView:
                do_scroll_x: False
                BoxLayout:
                    id: feed
                    orientation: "vertical"
                    size_hint_y: None
                    height: self.minimum_height
                    spacing: dp(12)

                    Label:
                        text: "Não há postagens no momento"
                        font_size: sp(18)
                        color: 0,0,0,1
                        halign: "center"
                        valign: "middle"
                        size_hint_y: None
                        height: self.texture_size[1] + dp(20)

        BoxLayout:
            size_hint_y: None
            height: dp(70)
            padding: dp(5)
            spacing: dp(0)
            canvas.before:
                Color:
                    rgba: 0.5, 0.5, 0.5, 1
                Rectangle:
                    pos: self.pos
                    size: self.size

            BoxLayout:
                orientation: "vertical"
                size_hint_x: 1
                IconButton:
                    source: "app/Frontend/Assets/Home.png"
                    size_hint: None, None
                    size: dp(50), dp(50)
                    pos_hint: {"center_x": .5}
                    on_press: root.ir_para_home()
                Label:
                    text: "Início"
                    font_size: sp(13)
                    halign: "center"
                    valign: "middle"
                    text_size: self.size
                    color: 0,0,0,1

            Widget:
                size_hint_x: None
                width: dp(1)
                canvas.before:
                    Color:
                        rgba: 0,0,0,0.3
                    Rectangle:
                        pos: self.pos
                        size: self.size

            BoxLayout:
                orientation: "vertical"
                size_hint_x: 1
                IconButton:
                    source: "app/Frontend/Assets/PontoColeta.png"
                    size_hint: None, None
                    size: dp(50), dp(50)
                    pos_hint: {"center_x": .5}
                    on_press: root.ir_para_reciclar()
                Label:
                    text: "Reciclar"
                    font_size: sp(13)
                    halign: "center"
                    valign: "middle"
                    text_size: self.size
                    color: 0,0,0,1

            Widget:
                size_hint_x: None
                width: dp(1)
                canvas.before:
                    Color:
                        rgba: 0,0,0,0.3
                    Rectangle:
                        pos: self.pos
                        size: self.size

            BoxLayout:
                orientation: "vertical"
                size_hint_x: 1
                IconButton:
                    source: "app/Frontend/Assets/Notificacao.png"
                    size_hint: None, None
                    size: dp(50), dp(50)
                    pos_hint: {"center_x": .5}
                    on_press: root.ir_para_notificacoes()
                Label:
                    text: "Notificações"
                    font_size: sp(13)
                    halign: "center"
                    valign: "middle"
                    text_size: self.size
                    color: 0,0,0,1
'''

Builder.load_string(interface_TelaInicioEmp)


class IconButton(ButtonBehavior, Image):
    pass


class FotoPerfil(ButtonBehavior, Image):
    def on_release(self):
        self.abrir_menu_lateral()

    def abrir_menu_lateral(self):
        app = App.get_running_app()

        # Container do card
        menu = BoxLayout(orientation='vertical', padding=dp(12), spacing=dp(8), size_hint=(1, 1))

        # Fundo bege translúcido
        def _draw_bg(instance, *l):
            instance.canvas.before.clear()
            with instance.canvas.before:
                Color(0.85, 0.83, 0.65, 0.95)
                RoundedRectangle(pos=instance.pos, size=instance.size, radius=[10])
        menu.bind(pos=_draw_bg, size=_draw_bg)
        _draw_bg(menu)

        # Linha com a foto e o nome
        linha_superior = BoxLayout(orientation='horizontal', spacing=dp(10), size_hint_y=None, height=dp(40))

        img_perfil = Image(
            source=app.empresa_foto if getattr(app, "empresa_foto", None) else "app/Frontend/Assets/Foto_Perfil.png",
            size_hint=(None, None),
            size=(dp(30), dp(30))
        )
        linha_superior.add_widget(img_perfil)

        nome_emp = app.empresa_nome if getattr(app, "empresa_nome", None) else "Empresa"
        lbl_nome = Label(
            text=f"[b]{nome_emp}[/b]",
            markup=True,
            color=(0, 0, 0, 1),
            halign='left',
            valign='middle'
        )
        lbl_nome.bind(size=lambda inst, val: setattr(inst, 'text_size', val))
        linha_superior.add_widget(lbl_nome)

        menu.add_widget(linha_superior)

        # Botão sair logo abaixo
        btn_sair = Button(
            text="Sair",
            size_hint_y=None,
            height=dp(34),
            background_normal='',
            background_color=(0, 0, 0, 0),
            color=(0, 0, 0, 1),
            halign='left'
        )
        btn_sair.bind(on_release=self._logout_and_close)
        menu.add_widget(btn_sair)

        popup = Popup(
            title='',
            content=menu,
            size_hint=(0.34, 0.18),
            pos_hint={"x": 0.02, "top": 0.92},
            background_color=(0, 0, 0, 0),
            separator_height=0,
            auto_dismiss=True
        )

        try:
            popup.overlay_color = (0, 0, 0, 0.45)
        except Exception:
            pass

        self.popup = popup
        self.popup.open()

    def _logout_and_close(self, instance):
        if hasattr(self, 'popup'):
            self.popup.dismiss()
        app = App.get_running_app()
        mgr = app.root
        for s in getattr(mgr, "screens", []):
            if getattr(s, "name", None) in ("TelaInicio", "Login", "TelaLogin"):
                mgr.current = getattr(s, "name")
                break
        print("Logout acionado")


class HeaderEmpresa(BoxLayout):
    pass


class TelaInicialEmpresa(Screen):
    def on_pre_enter(self, *args):
        app = App.get_running_app()
        try:
            self.ids.header.ids.lbl_nome.text = app.empresa_nome if getattr(app, "empresa_nome", None) else "Empresa"
        except Exception:
            pass

    def ir_para_home(self): ...
    
    def ir_para_reciclar(self):
        app = App.get_running_app()
        app.root.current = "TelaMapaEmp"

    def ir_para_notificacoes(self):
        app = App.get_running_app()
        app.root.current = "TelaNotificacaoEmp"