# tela_cadastro.py
from kivy.app import App
from kivy.uix.boxlayout import BoxLayout
from kivy.lang import Builder

#Width

# KV em string para evitar criar mais arquivos; mantém a interface separada do main
interface_TelaCadastroUsuario = '''
<CadastroScreen>:
    orientation: 'vertical'
    padding: dp(16)
    spacing: dp(8)

    canvas.before:
        Color:
            rgba: 0.5, 0.5, 0.5, 1
        Rectangle:
            pos: self.pos
            size: self.size

    Label:
        text: '[b]Recy[color=00FF00]Tech[/color][/b]'
        markup: True
        font_size: sp(28)
        size_hint_y: None
        height: self.texture_size[1] + dp(5)
        halign: 'center'
        valign: 'middle'
        text_size: self.width, None

    BoxLayout:
        orientation: 'vertical'
        spacing: dp(8)
        size_hint_y: None
        height: self.minimum_height   # ajusta altura automaticamente

        canvas.before:
            Color:
                rgba: 0.2, 0.2, 0.2, 1   # cor do painel
            Rectangle:
                pos: self.pos
                size: self.size

        BoxLayout:
            size_hint_y: None
            height: dp(44)
            spacing: dp(8)

            ToggleButton:
                text: 'Usuário'
                group: 'tipo'
                state: 'down'
                background_normal: ''
                background_color: 0.2,0.6,0.8,1
                color: 1,1,1,1

            ToggleButton:
                text: 'Empresa'
                group: 'tipo'
                background_normal: ''
                background_color: 0.7,0.7,0.7,1
                color: 0,0,0,1

        AnchorLayout:
            size_hint_y: None
            height: dp(40)
            anchor_x: 'center'
            TextInput:
                id: email
                hint_text: 'Digite seu email'
                multiline: False
                size_hint: 0.9, None   # usa 90% da largura da tela
                height: dp(40)
                font_size: sp(16)

        AnchorLayout:
            size_hint_y: None
            height: dp(40)
            anchor_x: 'center'
            TextInput:
                id: senha
                hint_text: 'Senha'
                password: True
                multiline: False
                size_hint: 0.9, None
                height: dp(40)
                font_size: sp(16)

        AnchorLayout:
            size_hint_y: None
            height: dp(40)
            anchor_x: 'center'
            TextInput:
                id: confirmar
                hint_text: 'Confirmar senha'
                password: True
                multiline: False
                size_hint: 0.9, None
                height: dp(40)
                font_size: sp(16)

    Button:
        text: 'CADASTRAR'
        size_hint_y: None
        height: dp(52)
        background_normal: ''
        background_color: 0,0,0,1
        color: 1,1,1,1
        font_size: sp(18)
        size_hint_x: 0.9
        pos_hint: {'center_x': 0.5}   # centraliza horizontalmente

    Label:
        text: '[u]Voltar para o login[/u]'
        markup: True
        size_hint_y: None
        height: dp(30)
        halign: 'center'
        valign: 'middle'
        text_size: self.width, None
        font_size: sp(14)
        size_hint_x: 0.9
        pos_hint: {'center_x': 0.5}
'''

# Carrega a interface KV
Builder.load_string(interface_TelaCadastroUsuario)

class CadastroScreen(BoxLayout):
    pass

class TelaCadastroUsuario(App):
    def build(self):
        return CadastroScreen()

if __name__ == "__main__":
    TelaCadastroUsuario().run()