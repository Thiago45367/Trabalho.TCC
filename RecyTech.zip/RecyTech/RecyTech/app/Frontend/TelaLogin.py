# tela_login.py
from kivy.app import App
from kivy.uix.screenmanager import Screen
from kivy.lang import Builder
from kivy.uix.popup import Popup
from kivy.uix.label import Label

from app.Backend.Controle.ControleLogin import ControleLogin

# KV em string
interface_TelaLogin = '''
<TelaLogin>:
    canvas.before:
        Color:
            rgba: 0.5, 0.5, 0.5, 1
        Rectangle:
            pos: self.pos
            size: self.size

    BoxLayout:
        orientation: "vertical"

        # --- CENTRO ---
        BoxLayout:
            orientation: "vertical"
            size_hint_y: 0.9
            spacing: dp(20)
            padding: [dp(30), dp(50), dp(30), dp(30)]
            pos_hint: {"center_x": 0.5, "center_y": 0.5}

            Label:
                text: "[b]Recy[/b][color=00ff00]Tech[/color]"
                markup: True
                font_size: "28sp"
                size_hint_y: None
                height: dp(50)
                halign: "center"

            # --------- EMAIL ----------
            BoxLayout:
                orientation: "vertical"
                size_hint_y: None
                height: dp(70)  # controla o espaço total do bloco (label + input)

                Label:
                    text: "Email:"
                    size_hint_y: None
                    height: dp(20)
                    halign: "left"
                    valign: "middle"
                    text_size: self.size
                    color: (0, 0, 0, 1)
                    padding_x: dp(40)   # joguei um pouco pra direita
                    pos_hint: {"y": 0.2}  # desce um pouco

                BoxLayout:
                    orientation: "horizontal"
                    spacing: dp(10)
                    size_hint_y: None
                    height: dp(45)

                    Image:
                        source: "app/Frontend/Assets/Envelope.png"
                        size_hint: None, None
                        size: dp(25), dp(25)
                        pos_hint: {"center_y": 0.5}

                    TextInput:
                        id: email_input
                        hint_text: "Digite seu email"
                        multiline: False
                        size_hint_x: 1
                        font_size: "16sp"

            # --------- SENHA ----------
            BoxLayout:
                orientation: "vertical"
                size_hint_y: None
                height: dp(70)

                Label:
                    text: "Senha:"
                    size_hint_y: None
                    height: dp(20)
                    halign: "left"
                    valign: "middle"
                    text_size: self.size
                    color: (0, 0, 0, 1)
                    padding_x: dp(40)
                    pos_hint: {"y": 0.2}

                BoxLayout:
                    orientation: "horizontal"
                    spacing: dp(10)
                    size_hint_y: None
                    height: dp(45)

                    Image:
                        source: "app/Frontend/Assets/Cadeado.png"
                        size_hint: None, None
                        size: dp(25), dp(25)
                        pos_hint: {"center_y": 0.5}

                    TextInput:
                        id: senha_input
                        hint_text: "Senha"
                        password: True
                        multiline: False
                        size_hint_x: 1
                        font_size: "16sp"

            # Botão Entrar
            AnchorLayout:
                anchor_x: "center"
                anchor_y: "center"
                size_hint_y: None
                height: dp(70)

                Button:
                    text: "ENTRAR"
                    size_hint: None, None
                    size: dp(160), dp(50)
                    background_color: (0, 0, 0, 0)
                    color: (1, 1, 1, 1)
                    canvas.before:
                        Color:
                            rgba: (0, 0, 0, 1)
                        RoundedRectangle:
                            pos: self.pos
                            size: self.size
                            radius: [25]
                    on_release: root.fazer_login()

        # --- RODAPÉ ESQUERDA ---
        BoxLayout:
            orientation: "horizontal"
            size_hint_y: 0.1
            padding: [dp(15), dp(10)]
            spacing: dp(5)

            Label:
                text: "Não tem uma conta?"
                color: (1, 1, 1, 1)
                size_hint: None, None
                height: dp(20)
                width: self.texture_size[0]

            Button:
                text: "Cadastre-se"
                background_color: (0, 0, 0, 0)
                color: (0, 1, 0, 1)
                size_hint: None, None
                height: dp(20)
                width: self.texture_size[0]
                on_release: app.root.current = "TelaCadastroUsuario"
'''

Builder.load_string(interface_TelaLogin)

class TelaLogin(Screen):
    def fazer_login(self):
        email = self.ids.email_input.text.strip()
        senha = self.ids.senha_input.text.strip()

        # 🚨 Verificação de campos vazios
        if not email or not senha:
            Popup(
                title="Atenção",
                content=Label(text="Por favor, preencha todos os campos."),
                size_hint=(0.6, 0.4)
            ).open()
            return

        controle = ControleLogin()
        usuario = controle.fazer_login(email, senha)

        if usuario:  
            # Aqui depende do que o DAO retorna
            # Se for string ("usuario"/"empresa"), não existe usuario.nome_Usuario
            # Então adaptei para exibir apenas o tipo.
            Popup(
                title="Sucesso",
                content=Label(text=f"Login bem-sucedido! Tipo: {usuario}"),
                size_hint=(0.6, 0.4)
            ).open()

            # 🔹 Se for usuário comum
            if usuario == "usuario":
                self.manager.current = "TelaInicioUs"
            # 🔹 Se for empresa
            elif usuario == "empresa":
                self.manager.current = "TelaInicioEmp"

        else:
            Popup(
                title="Erro",
                content=Label(text="Email ou senha inválidos."),
                size_hint=(0.6, 0.4)
            ).open()
            
class TelaLoginApp(App):
    def build(self):
        return TelaLogin()

if __name__ == "__main__":
    TelaLoginApp().run()