# tela_cadastro.py
from kivy.app import App
from kivy.uix.boxlayout import BoxLayout
from kivy.lang import Builder
from kivy.config import Config
Config.set('graphics', 'width', '260')
Config.set('graphics', 'height', '540')


# KV em string para evitar criar mais arquivos; mantém a interface separada do main
interface_TelaLogin = '''
<LoginScreen>:
    canvas.before:
        Color:
            rgba: 0.5, 0.5, 0.5, 1  # fundo cinza
        Rectangle:
            pos: self.pos
            size: self.size

    BoxLayout:
        orientation: "vertical"
        padding: [0, 0, 0, dp(120)]   # <<< empurra logo/email/senha pra cima
        spacing: dp(15)

        # --- BLOCO DE CIMA (logo, email, senha) ---
        BoxLayout:
            orientation: 'vertical'
            spacing: dp(15)
            size_hint: 0.8, None
            height: self.minimum_height
            pos_hint: {"center_x": 0.5}

            # Logo
            Label:
                text: "[b]Recy[/b][color=00ff00]Tech[/color]"
                markup: True
                font_size: 32
                size_hint_y: None
                height: dp(60)
                halign: "center"

            # Campo Email
            BoxLayout:
                orientation: "vertical"
                size_hint_y: None
                height: dp(90)

                Label:
                    text: "Email:"
                    size_hint_y: None
                    height: dp(20)
                    halign: "left"
                    valign: "middle"
                    text_size: self.size
                    color: (0, 0, 0, 1)
                    padding: [20, 0, 0, 0]

                BoxLayout:
                    orientation: "horizontal"
                    spacing: dp(10)
                    size_hint_y: None
                    height: dp(40)
                    padding: [-20, 0, 0, 0]

                    Image:
                        source: "Assets/Envelope.png"
                        size_hint: None, None
                        size: dp(25), dp(40)

                    TextInput:
                        hint_text: "Digite seu email"
                        multiline: False

            # Campo Senha
            BoxLayout:
                orientation: "vertical"
                size_hint_y: None
                height: dp(60)

                Label:
                    text: "Senha:"
                    size_hint_y: None
                    height: dp(20)
                    halign: "left"
                    valign: "middle"
                    text_size: self.size
                    color: (0, 0, 0, 1)
                    padding: [20, 0, 0, 0]

                BoxLayout:
                    orientation: "horizontal"
                    spacing: dp(10)
                    size_hint_y: None
                    height: dp(40)
                    padding: [-20, 0, 0, 0]

                    Image:
                        source: "Assets/cadeado.png"
                        size_hint: None, None
                        size: dp(25), dp(50)

                    TextInput:
                        hint_text: "Senha"
                        password: True
                        multiline: False

        # --- BOTÃO SEPARADO ---
        AnchorLayout:
            anchor_x: "center"
            anchor_y: "top"
            size_hint_y: None
            height: dp(80)   # espaço reservado pro botão

            Button:
                text: "ENTRAR"
                size_hint: None, None
                size: dp(150), dp(50)
                background_color: (0, 0, 0, 0)
                color: (1, 1, 1, 1)
                canvas.before:
                    Color:
                        rgba: (0, 0, 0, 1)
                    RoundedRectangle:
                        pos: self.pos
                        size: self.size
                        radius: [25]
                    
'''

# Carrega a interface KV
Builder.load_string(interface_TelaLogin)

class LoginScreen(BoxLayout):
    pass

class TelaLoginApp(App):
    def build(self):
        return LoginScreen()

if __name__ == "__main__":
    TelaLoginApp().run()
