import mysql.connector
from app.Backend.DataBase.conexao import criar_conexao, fechar_conexao

class DaoEmp:
    def __init__(self):
        pass  # Não mantém conexão aberta, cada método cria/fecha a sua

    def cadastrar_empresa(self, empresa):
        conexao = criar_conexao()
        if not conexao:
            print("❌ Sem conexão com o banco de dados")
            return False

        cursor = conexao.cursor()
        try:
            # --- validações antes do cadastro ---
            if self.existe_email_Empresa(empresa.email_Empresa):
                print("❌ Email já cadastrado!")
                return False

            if self.existe_cnpj(empresa.cnpj):
                print("❌ CNPJ já cadastrado!")
                return False

            # 1️⃣ Inserir na tabela Empresa
            sql_empresa = """
            INSERT INTO Empresa (cnpj, nome_Empresa, email_Empresa, senha_Empresa, telefone_Empresa, id_Ponto_Coleta)
            VALUES (%s, %s, %s, %s, %s, %s)
            """
            valores_empresa = (
                empresa.cnpj,
                empresa.nome_Empresa,
                empresa.email_Empresa,
                empresa.senha_Empresa,
                empresa.telefone_Empresa,
                empresa.id_Ponto_Coleta
            )
            cursor.execute(sql_empresa, valores_empresa)

            # 2️⃣ Inserir também na tabela Login com tipo "empresa"
            sql_login = """
            INSERT INTO Login (email_Login, senha_Login, tipo)
            VALUES (%s, %s, %s)
            """
            valores_login = (
                empresa.email_Empresa,
                empresa.senha_Empresa,
                "empresa"
            )
            cursor.execute(sql_login, valores_login)

            conexao.commit()

            # 🔹 já busca o usuário recém cadastrado
            return self.buscar_empresa_por_email(empresa.email_Empresa)

        except mysql.connector.Error as erro:
            conexao.rollback()
            print(f"❌ Erro ao cadastrar usuário: {erro}")
            return None
        finally:
            cursor.close()
            fechar_conexao(conexao)

    def existe_email_Empresa(self, email_Empresa):
        """Verifica se já existe email"""
        conexao = criar_conexao()
        if not conexao:
            return False

        cursor = conexao.cursor()
        sql = "SELECT COUNT(*) FROM Empresa WHERE email_Empresa = %s"
        cursor.execute(sql, (email_Empresa,))
        (quantidade,) = cursor.fetchone()

        cursor.close()
        fechar_conexao(conexao)
        return quantidade > 0

    def existe_cnpj(self, cnpj):
        """Verifica se já existe CNPJ"""
        conexao = criar_conexao()
        if not conexao:
            return False

        cursor = conexao.cursor()
        sql = "SELECT COUNT(*) FROM Empresa WHERE cnpj = %s"
        cursor.execute(sql, (cnpj,))
        (quantidade,) = cursor.fetchone()

        cursor.close()
        fechar_conexao(conexao)
        return quantidade > 0

    def buscar_empresa_por_email(self, email):
        """🔹 Retorna dados do usuário (dict) pelo email"""
        conexao = criar_conexao()
        if not conexao:
            print("❌ Sem conexão com o banco de dados")
            return None

        cursor = conexao.cursor(dictionary=True)
        sql = "SELECT id_Empresa, nome_Empresa, email_Empresa, NULL as foto FROM Empresa WHERE email_Empresa = %s"
        cursor.execute(sql, (email,))
        empresa = cursor.fetchone()

        cursor.close()
        fechar_conexao(conexao)

        if empresa:
            return {
                "id": empresa["id_Empresa"],
                "nome": empresa["nome_Empresa"],
                "email": empresa["email_Empresa"],
                "foto": empresa.get("foto") or "app/Frontend/Assets/Foto_Perfil.png"
            }
        return None
