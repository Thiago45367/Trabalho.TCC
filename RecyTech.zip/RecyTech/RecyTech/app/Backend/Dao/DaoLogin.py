# DaoLogin.py
from app.Backend.DataBase.conexao import criar_conexao, fechar_conexao

class DaoLogin:
    def __init__(self):
        pass

    def verificar_login(self, email, senha):
        """
        Verifica se existe login com email e senha na tabela Login.
        Retorna o tipo (usuario/empresa) se encontrar, caso contrário None.
        """
        conexao = criar_conexao()
        if not conexao:
            return None
        
        try:
            cursor = conexao.cursor(dictionary=True)
            query = """
                SELECT tipo 
                FROM Login 
                WHERE email_Login = %s AND senha_Login = %s
            """
            cursor.execute(query, (email, senha))
            resultado = cursor.fetchone()
            return resultado  # {"tipo": "..."} ou None
        except Exception as e:
            print(f"Erro ao verificar login: {e}")
            return None
        finally:
            if cursor:
                cursor.close()
            fechar_conexao(conexao)