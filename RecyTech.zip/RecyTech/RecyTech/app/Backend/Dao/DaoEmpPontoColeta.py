# DaoEmpPontoColeta.py
import mysql.connector
from app.Backend.DataBase.conexao import criar_conexao, fechar_conexao
from app.Backend.Modelo.ModeloPonto_Coleta import ModeloPontoColeta

class DaoEmpPontoColeta:
    def __init__(self):
        self.conexao = criar_conexao()

    # 🔹 Criar ponto de coleta
    def cadastrar_ponto(self, ponto: ModeloPontoColeta):
        try:
            cursor = self.conexao.cursor(dictionary=True)
            sql = """
                INSERT INTO Ponto_Coleta 
                (nome_Ponto, cep, horario, tipo_Coleta, remuneracao, latitude, longitude, id_Empresa)
                VALUES (%s, %s, %s, %s, %s, %s, %s, %s)
            """
            valores = (
                ponto.nome_Ponto,
                ponto.cep,
                ponto.horario,
                ponto.tipo_Coleta,
                ponto.remuneracao,
                ponto.latitude,
                ponto.longitude,
                ponto.id_Empresa
            )
            cursor.execute(sql, valores)
            self.conexao.commit()
            return cursor.lastrowid
        except Exception as e:
            print("❌ Erro ao cadastrar ponto:", e)
            return None
        finally:
            cursor.close()

    # 🔹 Listar todos pontos
    def listar_pontos(self):
        try:
            cursor = self.conexao.cursor(dictionary=True)
            cursor.execute("SELECT * FROM Ponto_Coleta")
            return cursor.fetchall()
        except Exception as e:
            print("❌ Erro ao listar pontos:", e)
            return []
        finally:
            cursor.close()

    # 🔹 Buscar ponto por ID
    def buscar_ponto_por_id(self, id_ponto):
        try:
            cursor = self.conexao.cursor(dictionary=True)
            cursor.execute("SELECT * FROM Ponto_Coleta WHERE id_Ponto_Coleta = %s", (id_ponto,))
            return cursor.fetchone()
        except Exception as e:
            print("❌ Erro ao buscar ponto:", e)
            return None
        finally:
            cursor.close()

    # 🔹 Atualizar ponto
    def atualizar_ponto(self, id_ponto, endereco=None, cidade=None, estado=None, cep=None):
        try:
            cursor = self.conexao.cursor()
            sql = """
                UPDATE Ponto_Coleta 
                SET cep = %s
                WHERE id_Ponto_Coleta = %s
            """
            cursor.execute(sql, (cep, id_ponto))
            self.conexao.commit()
            return cursor.rowcount > 0
        except Exception as e:
            print("❌ Erro ao atualizar ponto:", e)
            return False
        finally:
            cursor.close()

    # 🔹 Deletar ponto
    def deletar_ponto(self, id_ponto):
        try:
            cursor = self.conexao.cursor()
            cursor.execute("DELETE FROM Ponto_Coleta WHERE id_Ponto_Coleta = %s", (id_ponto,))
            self.conexao.commit()
            return cursor.rowcount > 0
        except Exception as e:
            print("❌ Erro ao deletar ponto:", e)
            return False
        finally:
            cursor.close()

    def __del__(self):
        fechar_conexao(self.conexao)
