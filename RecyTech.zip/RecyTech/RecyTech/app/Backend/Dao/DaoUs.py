# DaoUsuario.py
import mysql.connector
from app.Backend.DataBase.conexao import criar_conexao, fechar_conexao

class DaoUs:
    def __init__(self):
        self.conexao = criar_conexao()

    def cadastrar_usuario(self, usuario):
        if not self.conexao:
            print("❌ Sem conexão com o banco de dados")
            return False

        # --- antes de cadastrar, checa se já existe email ou apelido ---
        if self.existe_email(usuario.email):
            print("Email já cadastrados!")
            return False
        
        if self.existe_apelido(usuario.apelido):
            print("Apelido já cadastrados!")
            return False

        cursor = self.conexao.cursor()
        sql = """
        INSERT INTO usuario (email, senha, apelido, data_Nascimento)
        VALUES (%s, %s, %s, %s)
        """
        valores = (usuario.email, usuario.senha, usuario.apelido, usuario.data_nascimento)

        try:
            cursor.execute(sql, valores)
            self.conexao.commit()
            print("✅ Usuário cadastrado com sucesso!")
            return True
        except mysql.connector.Error as erro:
            print(f"❌ Erro ao cadastrar usuário: {erro}")
            return False
        finally:
            cursor.close()
            fechar_conexao(self.conexao)

    def existe_email(self, email):
        """Verifica se já existe email"""
        cursor = self.conexao.cursor()
        sql = "SELECT COUNT(*) FROM usuario WHERE email = %s"
        valores = (email,)
        cursor.execute(sql, valores)
        (quantidade,) = cursor.fetchone()
        cursor.close()
        return quantidade > 0
    
    def existe_apelido(self, apelido):
        """Verifica se já existe apelido"""
        cursor = self.conexao.cursor()
        sql = "SELECT COUNT(*) FROM usuario WHERE apelido = %s"
        valores = (apelido,)
        cursor.execute(sql, valores)
        (quantidade,) = cursor.fetchone()
        cursor.close()
        return quantidade > 0