import mysql.connector
from mysql.connector import Error

def criar_conexao():
    """Cria e retorna a conexão com o banco MySQL."""
    try:
        conexao = mysql.connector.connect(
            host="localhost",       # servidor do banco
            user="root",            # seu usuário do MySQL
            password="",            # sua senha do MySQL
            database="banco_recytech"     # nome do banco de dados
        )
        if conexao.is_connected():
            print("Conectado ao banco de dados MySQL")
            return conexao
    except Error as e:
        print(f"Erro ao conectar no MySQL: {e}")
        return None

def fechar_conexao(conexao):
    """Fecha a conexão com o banco."""
    if conexao and conexao.is_connected():
        conexao.close()
        print("Conexão com MySQL encerrada")

# 🔎 Teste rápido
if __name__ == "__main__":
    conexao = criar_conexao()
    fechar_conexao(conexao)