import datetime

class ModeloPontos_Coleta:
    def __init__(self, id_Ponto_Coleta: int, nome_Ponto: str, cep: str, horario: datetime, tipo_Coleta: str, remuneracao: str, id_Empresa: int):
        self.id_Ponto_Coleta = id_Ponto_Coleta
        self.nome_Ponto = nome_Ponto
        self.cep = cep
        self.horario = horario
        self.tipo_Coleta = tipo_Coleta
        self.remuneracao = remuneracao
        self.id_Empresa = id_Empresa