from datetime import datetime

class ModeloPontoColeta:
    def __init__(self,
                 id_Ponto_Coleta: int = None,
                 nome_Ponto: str = None,
                 cep: str = None,
                 horario: datetime = None,
                 tipo_Coleta: str = None,
                 remuneracao: str = None,
                 latitude: float = None,
                 longitude: float = None,
                 id_Empresa: int = None):  # 🔹 renomeado de fk_Empresa -> id_Empresa
        
        self.id_Ponto_Coleta = id_Ponto_Coleta
        self.nome_Ponto = nome_Ponto
        self.cep = cep
        self.horario = horario
        self.tipo_Coleta = tipo_Coleta
        self.remuneracao = remuneracao
        self.latitude = latitude
        self.longitude = longitude
        self.id_Empresa = id_Empresa  # 🔹 agora bate com o ControleEmp
