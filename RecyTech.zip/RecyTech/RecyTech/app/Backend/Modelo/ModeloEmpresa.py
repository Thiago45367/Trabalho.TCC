class ModeloEmpresa:
    def __init__(self, id_Empresa: int, cnpj: str, nome_Empresa: str, telefone: str, id_Ponto_Coleta: int):
        self.id_Empresa = id_Empresa
        self.cnpj = cnpj
        self.nome_Empresa = nome_Empresa
        self.telefone = telefone
        self.id_Ponto_Coleta = id_Ponto_Coleta