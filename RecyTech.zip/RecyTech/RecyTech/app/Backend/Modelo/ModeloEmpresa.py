class ModeloEmpresa:
    def __init__(self, cnpj: str, nome_Empresa: str, email_Empresa: str, senha_Empresa: str, telefone_Empresa: str, id_Ponto_Coleta: int, id_Empresa = None):
        self.id_Empresa = id_Empresa
        self.cnpj = cnpj
        self.nome_Empresa = nome_Empresa
        self.email_Empresa = email_Empresa
        self.senha_Empresa = senha_Empresa
        self.telefone_Empresa = telefone_Empresa
        self.id_Ponto_Coleta = id_Ponto_Coleta