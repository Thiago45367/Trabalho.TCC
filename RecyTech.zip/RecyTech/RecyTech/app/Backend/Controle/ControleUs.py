# ControleUsuario.py
from app.Backend.Modelo.ModeloUsuario import ModeloUsuario
from app.Backend.Dao.DaoUs import DaoUs

class ControleUsu:
    def __init__(self):
        # sempre que o controle for chamado, ele cria um DAO para falar com o banco
        self.dao = DaoUs()

    def cadastrar_usuario(self, email, senha, apelido, data_nascimento):
        # Criando o modelo de usuário
        usuario = ModeloUsuario(
            email=email,
            senha=senha,
            apelido=apelido,
            data_nascimento=data_nascimento
        )

        # Envia para o DAO
        return self.dao.cadastrar_usuario(usuario)
