# ControleLogin.py
from app.Backend.Dao.DaoLogin import DaoLogin

class ControleLogin:
    def __init__(self):
        self.dao = DaoLogin()

    def fazer_login(self, email, senha):
        """
        Chama o DAO para verificar se o login existe.
        Retorna o tipo de usuário se encontrado, caso contrário None.
        """
        resultado = self.dao.verificar_login(email, senha)
        
        if resultado:
            return resultado['tipo']   # "usuario" ou "empresa"
        else:
            return None
