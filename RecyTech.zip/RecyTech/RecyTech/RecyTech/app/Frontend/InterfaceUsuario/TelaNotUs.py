from kivy.app import App
from kivy.uix.boxlayout import BoxLayout
from kivy.lang import Builder
from kivy.uix.behaviors import ButtonBehavior
from kivy.uix.image import Image

# Classe para usar imagem como botão
class IconButton(ButtonBehavior, Image):
    pass

class TelaNotificacoesEmp(BoxLayout):
    pass

interface_kv = '''
<TelaNotificacoesEmp>:
    orientation: "vertical"

    canvas.before:
        Color:
            rgba: 0.4, 0.8, 0.4, 1  # Fundo verde
        Rectangle:
            pos: self.pos
            size: self.size

    # ----- Barra de Pesquisa -----
    BoxLayout:
        size_hint_y: None
        height: dp(50)
        padding: dp(10)
        spacing: dp(10)
        canvas.before:
            Color:
                rgba: 0.5, 0.5, 0.5, 1
            Rectangle:
                pos: self.pos
                size: self.size

        Image:
            source: "../Assets/Search.png"
            size_hint_x: None
            width: dp(25)

        TextInput:
            hint_text: "Pesquisar"
            multiline: False
            background_normal: ""
            background_color: 1,1,1,1
            foreground_color: 0,0,0,1

        Image:
            source: "../Assets/Config.png"
            size_hint_x: None
            width: dp(25)

    # ----- Título -----
    Label:
        text: "Todos"
        size_hint_y: None
        height: dp(30)
        font_size: dp(16)
        color: 0,0,0,1
        bold: True
        halign: "left"
        valign: "middle"
        text_size: self.size
        padding_x: dp(10)

    # ----- Lista de Notificações -----
    ScrollView:
        do_scroll_x: False
        BoxLayout:
            orientation: "vertical"
            size_hint_y: None
            height: self.minimum_height
            spacing: dp(12)
            padding: dp(10)

            # ---- Modelo de Card de Notificação ----
            BoxLayout:
                size_hint_y: None
                height: dp(70)
                padding: dp(10)
                spacing: dp(10)
                canvas.before:
                    Color:
                        rgba: 0, 0, 0, 0.15   # sombra leve
                    RoundedRectangle:
                        pos: self.x+2, self.y-2   # deslocamento da sombra
                        size: self.size
                        radius: [12]
                    Color:
                        rgba: 0.2, 0.8, 0.2, 1   # fundo branco do card
                    RoundedRectangle:
                        pos: self.pos
                        size: self.size
                        radius: [12]

                Image:
                    source: "../Assets/Reciclagem.png"
                    size_hint_x: None
                    width: dp(45)
                Label:
                    text: "O cliente João Silva agendou uma coleta de lixo eletrônico para o dia 07/06/2025 às 14h"
                    color: 0,0,0,1
                    halign: "left"
                    valign: "middle"
                    text_size: self.size

            BoxLayout:
                size_hint_y: None
                height: dp(70)
                padding: dp(10)
                spacing: dp(10)
                canvas.before:
                    Color:
                        rgba: 0, 0, 0, 0.15
                    RoundedRectangle:
                        pos: self.x+2, self.y-2
                        size: self.size
                        radius: [12]
                    Color:
                        rgba: 0.2, 0.8, 0.2, 1
                    RoundedRectangle:
                        pos: self.pos
                        size: self.size
                        radius: [12]

                Image:
                    source: "../Assets/Reciclagem.png"
                    size_hint_x: None
                    width: dp(45)
                Label:
                    text: "A coleta marcada para 06/06/2025 às 10h com Maria foi cancelada"
                    color: 0,0,0,1
                    halign: "left"
                    valign: "middle"
                    text_size: self.size

            BoxLayout:
                size_hint_y: None
                height: dp(70)
                padding: dp(10)
                spacing: dp(10)
                canvas.before:
                    Color:
                        rgba: 0, 0, 0, 0.15
                    RoundedRectangle:
                        pos: self.x+2, self.y-2
                        size: self.size
                        radius: [12]
                    Color:
                        rgba: 0.2, 0.8, 0.2, 1
                    RoundedRectangle:
                        pos: self.pos
                        size: self.size
                        radius: [12]

                Image:
                    source: "../Assets/Reciclagem.png"
                    size_hint_x: None
                    width: dp(45)
                Label:
                    text: "O cliente Eduardo Lima solicitou uma coleta para o mesmo dia, até às 17h"
                    color: 0,0,0,1
                    halign: "left"
                    valign: "middle"
                    text_size: self.size

            BoxLayout:
                size_hint_y: None
                height: dp(70)
                padding: dp(10)
                spacing: dp(10)
                canvas.before:
                    Color:
                        rgba: 0, 0, 0, 0.15
                    RoundedRectangle:
                        pos: self.x+2, self.y-2
                        size: self.size
                        radius: [12]
                    Color:
                        rgba: 0.2, 0.8, 0.2, 1
                    RoundedRectangle:
                        pos: self.pos
                        size: self.size
                        radius: [12]

                Image:
                    source: "../Assets/Reciclagem.png"
                    size_hint_x: None
                    width: dp(45)
                Label:
                    text: "Cliente Luciana Andrade avaliou a última coleta com 5 estrelas"
                    color: 0,0,0,1
                    halign: "left"
                    valign: "middle"
                    text_size: self.size

    # ----- Barra inferior -----
    BoxLayout:
        size_hint_y: None
        height: dp(70)
        spacing: dp(30)
        padding: dp(10)

        canvas.before:
            Color:
                rgba: 0.5, 0.5, 0.5, 1
            Rectangle:
                pos: self.pos
                size: self.size

        # Aba Início
        BoxLayout:
            orientation: "vertical"
            padding: [0, dp(10), 0, 0]
            IconButton:
                source: "../Assets/Home.png"
                size_hint: None, None
                size: dp(50), dp(50)
                pos_hint: {"center_x": .5}
                on_press: app.ir_para_home()
            Label:
                text: "Início"
                font_size: sp(12)
                halign: "center"
                valign: "middle"
                text_size: self.size
                color: 0,0,0,1

        # Aba Reciclar
        BoxLayout:
            orientation: "vertical"
            padding: [0, dp(10), 0, 0]
            IconButton:
                source: "../Assets/Reciclagem.png"
                size_hint: None, None
                size: dp(50), dp(50)
                pos_hint: {"center_x": .5}
                on_press: app.ir_para_reciclar()
            Label:
                text: "Reciclar"
                font_size: sp(12)
                halign: "center"
                valign: "middle"
                text_size: self.size
                color: 0,0,0,1

        # Aba Notificações
        BoxLayout:
            orientation: "vertical"
            padding: [0, dp(10), 0, 0]
            IconButton:
                source: "../Assets/Notificacao.png"
                size_hint: None, None
                size: dp(50), dp(50)
                pos_hint: {"center_x": .5}
                on_press: app.ir_para_notificacoes()
            Label:
                text: "Notificações"
                font_size: sp(12)
                halign: "center"
                valign: "middle"
                text_size: self.size
                color: 0,0,0,1
'''

class RecyTechNotificacoes(App):
    def build(self):
        Builder.load_string(interface_kv)
        return TelaNotificacoesEmp()

    def ir_para_home(self):
        print("🏠 Voltando para Home")

    def ir_para_reciclar(self):
        print("♻️ Indo para Reciclar")

    def ir_para_notificacoes(self):
        print("🔔 Já estamos na tela de Notificações")

if __name__ == "__main__":
    RecyTechNotificacoes().run()
