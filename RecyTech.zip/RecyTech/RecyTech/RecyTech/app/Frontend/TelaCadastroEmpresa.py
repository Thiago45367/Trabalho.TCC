# tela_cadastro.py
from kivy.app import App
from kivy.uix.boxlayout import BoxLayout
from kivy.lang import Builder
from kivy.metrics import dp, sp  # dp/sp = tamanhos adaptativos

from kivy.uix.popup import Popup
from kivy.uix.label import Label

#Importações dos arquivos.
from app.Backend.Controle.ControleUs import ControleUsu

# KV em string para evitar criar mais arquivos; mantém a interface separada do main
interface_TelaCadastroEmpresa = '''
<TelaCadastroEmp>:
    orientation: 'vertical'
    padding: dp(12)
    spacing: dp(6)

    canvas.before:
        Color:
            rgba: 0.5, 0.5, 0.5, 1
        Rectangle:
            pos: self.pos
            size: self.size

    # LOGO
    Label:
        text: '[b]Recy[color=00FF00]Tech[/color][/b]'
        markup: True
        font_size: sp(28)
        size_hint_y: None
        height: self.texture_size[1] + dp(6)
        halign: 'center'
        valign: 'middle'
        text_size: self.width, None

    # Um espacinho para aproximar do painel
    Widget:
        size_hint_y: None
        height: dp(6)

    # PAINEL CENTRAL ESCURO (90% da largura, centralizado)
    AnchorLayout:
        anchor_x: 'center'
        size_hint_y: None
        height: painel.height  # <- AnchorLayout acompanha a altura do painel

        BoxLayout:
            id: painel
            orientation: 'vertical'
            size_hint_x: 0.9
            size_hint_y: None
            height: self.minimum_height  # <- BoxLayout sim tem minimum_height
            padding: dp(10)
            spacing: dp(8)

            canvas.before:
                Color:
                    rgba: 0.2, 0.2, 0.2, 1
                RoundedRectangle:
                    pos: self.pos
                    size: self.size
                    radius: [dp(6)]

            # Abas Usuário/Empresa
            BoxLayout:
                size_hint_y: None
                height: dp(40)
                spacing: dp(8)

                ToggleButton:
                    text: 'Usuário'
                    group: 'tipo'
                    background_normal: ''
                    background_color: 0.75, 0.75, 0.75, 1
                    color: 0,0,0,1
                    font_size: sp(14)
                    on_release: app.root.current = "TelaCadastroUsuario"

                ToggleButton:
                    text: 'Empresa'
                    group: 'tipo'
                    state: 'down'
                    background_normal: ''
                    background_color: 0.12, 0.45, 0.80, 1
                    color: 1,1,1,1
                    font_size: sp(14)
                    on_release: app.root.current = "TelaCadastroEmpresa"


            # ===== CAMPOS =====

            # Email
            BoxLayout:
                orientation: 'vertical'
                size_hint_y: None
                height: dp(60)
                spacing: dp(2)

                Label:
                    text: 'Email:'
                    color: 1,1,1,1
                    size_hint_y: None
                    height: dp(16)
                    halign: 'left'
                    valign: 'middle'
                    text_size: self.size
                    font_size: sp(12)

                TextInput:
                    id: email
                    hint_text: 'Digite seu Email'
                    multiline: False
                    size_hint_y: None
                    height: dp(36)
                    font_size: sp(14)

            # CNPJ
            BoxLayout:
                orientation: 'vertical'
                size_hint_y: None
                height: dp(60)
                spacing: dp(2)

                Label:
                    text: 'CNPJ:'
                    color: 1,1,1,1
                    size_hint_y: None
                    height: dp(16)
                    halign: 'left'
                    valign: 'middle'
                    text_size: self.size
                    font_size: sp(12)

                TextInput:
                    id: email
                    hint_text: 'Digite seu CNPJ'
                    multiline: False
                    size_hint_y: None
                    height: dp(36)
                    font_size: sp(14)

            # Senha
            BoxLayout:
                orientation: 'vertical'
                size_hint_y: None
                height: dp(60)
                spacing: dp(2)

                Label:
                    text: 'Senha:'
                    color: 1,1,1,1
                    size_hint_y: None
                    height: dp(16)
                    halign: 'left'
                    valign: 'middle'
                    text_size: self.size
                    font_size: sp(12)

                TextInput:
                    id: senha
                    hint_text: 'Senha'
                    password: True
                    multiline: False
                    size_hint_y: None
                    height: dp(36)
                    font_size: sp(14)

            # Confirmar Senha
            BoxLayout:
                orientation: 'vertical'
                size_hint_y: None
                height: dp(60)
                spacing: dp(2)

                Label:
                    text: 'Confirmar Senha:'
                    color: 1,1,1,1
                    size_hint_y: None
                    height: dp(16)
                    halign: 'left'
                    valign: 'middle'
                    text_size: self.size
                    font_size: sp(12)

                TextInput:
                    id: confirmar
                    hint_text: 'Confirmar senha'
                    password: True
                    multiline: False
                    size_hint_y: None
                    height: dp(36)
                    font_size: sp(14)

            # Nome da Empresa
            BoxLayout:
                orientation: 'vertical'
                size_hint_y: None
                height: dp(60)
                spacing: dp(2)

                Label:
                    text: 'Nome da Empresa:'
                    color: 1,1,1,1
                    size_hint_y: None
                    height: dp(16)
                    halign: 'left'
                    valign: 'middle'
                    text_size: self.size
                    font_size: sp(12)

                TextInput:
                    id: nome_empresa
                    hint_text: 'Sua empresa'
                    multiline: False
                    size_hint_y: None
                    height: dp(36)
                    font_size: sp(14)

    # Botão principal (90% e centralizado)
    AnchorLayout:
        anchor_x: 'center'
        size_hint_y: None
        height: dp(50)

        Button:
            text: '[b]CADASTRAR[/b]'
            markup: True
            size_hint_x: 0.9
            height: dp(48)
            background_normal: ''   # remove estilo padrão
            background_color: 0, 0, 0, 0   # deixa transparente (canvas cuida da cor)
            color: 1, 1, 1, 1
            font_size: sp(16)
            on_release: root.cadastrar() 

            canvas.before:
                Color:
                    rgba: 0, 0, 0, 1   # fundo preto
                RoundedRectangle:
                    pos: self.pos
                    size: self.size
                    radius: [dp(24)]  # arredondado

    # Link de voltar
    AnchorLayout:
        anchor_x: 'center'
        size_hint_y: None
        height: dp(28)

        Label:
            text: '[u]Voltar para o login[/u]'
            markup: True
            size_hint_x: 0.9
            halign: 'center'
            valign: 'middle'
            text_size: self.size
            font_size: sp(12)
'''

# Carrega a interface KV
Builder.load_string(interface_TelaCadastroEmpresa)

from kivy.uix.popup import Popup
from kivy.uix.label import Label
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.button import Button
from kivy.uix.screenmanager import Screen

class TelaCadastroEmp(Screen):

    def cadastrar(self):
        email = self.ids.email.text
        senha = self.ids.senha.text
        confirmar = self.ids.confirmar.text
        apelido = self.ids.nome_usuario.text
        data_nascimento = self.ids.data_nascimento.text

        def mostrar_alerta(mensagem):
            # Label configurado para quebrar linha
            label = Label(
                text=mensagem,
                halign="center",
                valign="middle"
            )
            label.bind(
                width=lambda *x: label.setter("text_size")(label, (label.width, None))
            )

            # Layout com Label + Botão OK
            box = BoxLayout(orientation="vertical", spacing=10, padding=10)
            box.add_widget(label)

            btn_fechar = Button(text="OK", size_hint=(1, 0.3))
            box.add_widget(btn_fechar)

            popup = Popup(
                title="Atenção",
                content=box,
                size_hint=(0.9, 0.4),   # ocupa 90% da largura, 40% da altura
                auto_dismiss=False
            )

            btn_fechar.bind(on_release=popup.dismiss)
            popup.open()

        # ---------------- VALIDAÇÕES ----------------
        if not email.strip():
            mostrar_alerta("Preencha o campo de E-mail!")
            return
        if not senha.strip():
            mostrar_alerta("Preencha o campo de Senha!")
            return
        if not confirmar.strip():
            mostrar_alerta("Confirme sua Senha!")
            return
        if not apelido.strip():
            mostrar_alerta("Preencha o Apelido!")
            return
        if not data_nascimento.strip():
            mostrar_alerta("Preencha a Data de Nascimento!")
            return
        
        controle = ControleUsu()

        # Verificar se já existe
        if controle.dao.existe_email(email):
            mostrar_alerta("Email já cadastrados")
            return
        
        if controle.dao.existe_apelido(apelido):
            mostrar_alerta("Apelido já cadastrado!")
            return

        # --- Validação da data de nascimento ---
        from datetime import datetime

        # dentro do método cadastrar:
        try:
            data_obj = datetime.strptime(data_nascimento, "%d/%m/%Y")
            data_mysql = data_obj.strftime("%Y-%m-%d")  # formato aceito pelo MySQL
        except ValueError:
            mostrar_alerta("Digite a data de nascimento no formato DD/MM/AAAA")
            return

        if senha != confirmar:
            mostrar_alerta("Senhas não coincidem!")
            return

        # ---------------- CADASTRO ----------------
        controle = ControleUsu()
        sucesso = controle.cadastrar_usuario(
            email=email,
            senha=senha,
            apelido=apelido,
            data_nascimento=data_mysql  # você pode salvar direto como string
        )

        if sucesso:
            mostrar_alerta("✅ Cadastro Realizado com sucesso!")
        else:
            mostrar_alerta("❌ Erro ao cadastrar usuário. Tente novamente.")

class TelaCadastroEmprApp(App):
    def build(self):
        return TelaCadastroEmp()

if __name__ == "__main__":
    TelaCadastroEmprApp().run()