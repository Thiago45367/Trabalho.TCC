-- SQLBook: Code
CREATE SCHEMA IF NOT EXISTS `banco_recytech`;

USE  `banco_recytech`;

CREATE TABLE IF NOT EXISTS `Usuario` (
	`id_Usuario` int AUTO_INCREMENT NOT NULL UNIQUE,
	`email_Usuario` varchar(30) NOT NULL UNIQUE,
	`senha_Usuario` varchar(25) NOT NULL,
	`nome_Usuario` varchar(50) NOT NULL UNIQUE,
	`data_Nascimento` date NOT NULL,
	`tipo` VARCHAR(25) NOT NULL,
	PRIMARY KEY (`id_Usuario`)
);

CREATE TABLE IF NOT EXISTS `Empresa` (
	`id_Empresa` int AUTO_INCREMENT NOT NULL UNIQUE,
	`cnpj` varchar(30) NOT NULL UNIQUE,
	`nome_Empresa` varchar(30) NOT NULL UNIQUE,
	`email_Empresa` varchar(40) NOT NUll UNIQUE,
	`senha_Empresa` VARCHAR(30) NOT NULL,
	`telefone_Empresa` varchar(30) NOT NULL,
	`id_Ponto_Coleta` int,
	`tipo` VARCHAR(25) NOT NULL,
	PRIMARY KEY (`id_Empresa`)
);

CREATE TABLE IF NOT EXISTS `Login` (
	`id_Login` int AUTO_INCREMENT NOT NULL UNIQUE,
	`email_Login` varchar(50) NOT NULL UNIQUE,
	`senha_Login` varchar(30) NOT NULL,
	`tipo` varchar(20) NOT NULL
);

CREATE TABLE IF NOT EXISTS `Ponto_Coleta` (
	`id_Ponto_Coleta` int AUTO_INCREMENT NOT NULL UNIQUE,
	`nome_Ponto` varchar(30) NOT NULL,
	`cep` varchar(30) NOT NULL,
	`horario` varchar(30) NOT NULL,   -- apenas horário de funcionamento
	`tipo_Coleta` varchar(50) NOT NULL,
	`remuneracao` varchar(30) NOT NULL,
	`fk_Empresa` int NOT NULL,
    `latitude` DECIMAL(10,8) NOT NULL,
	`longitude` DECIMAL(11,8) NOT NULL,
	PRIMARY KEY (`id_Ponto_Coleta`)
);

CREATE TABLE IF NOT EXISTS `Notificacao_Usu` (
	`id_Notificacao_Us` int AUTO_INCREMENT NOT NULL UNIQUE,
	`data_Envio` date NOT NULL,
	`descricao` varchar(100) NOT NULL,
	`fk_Empresa` int NOT NULL,
	`fk_Usuario` int NOT NULL,
	PRIMARY KEY (`id_Notificacao_Us`)
);

CREATE TABLE IF NOT EXISTS `Notificacao_Emp` (
	`id_Notificacao_Epr` int AUTO_INCREMENT NOT NULL UNIQUE,
	`data_Envio` date NOT NULL,
	`descricao` varchar(100) NOT NULL,
	`fk_Empresa` int NOT NULL,
	PRIMARY KEY (`id_Notificacao_Epr`)
);

CREATE TABLE IF NOT EXISTS `Postagens` (
	`id_Post` int AUTO_INCREMENT NOT NULL UNIQUE,
	`id_Usuario` int NOT NULL,
	`conteudo_Post` text NOT NULL,
	`data_Post` datetime NOT NULL,
	`tipo` varchar(25) NOT NULL,
	PRIMARY KEY (`id_Post`)
);

CREATE TABLE IF NOT EXISTS `Comentarios` (
	`id_Comentarios` int AUTO_INCREMENT NOT NULL UNIQUE,
	`id_Post` int NOT NULL,
	`id_Usuario` int NOT NULL,
	`conteudo` text NOT NULL,
	`data_Comentario` datetime NOT NULL,
	PRIMARY KEY (`id_Comentarios`)
);

CREATE TABLE IF NOT EXISTS `Curtidas` (
	`id_Curtidas` int AUTO_INCREMENT NOT NULL UNIQUE,
	`id_Post` int NOT NULL,
	PRIMARY KEY (`id_Curtidas`)
);