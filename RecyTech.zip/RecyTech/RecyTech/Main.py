import sys
import os

# Garante que a pasta raiz esteja no path
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

# Importa a tela
from app.Frontend.TelaLogin import TelaLoginApp
from app.Frontend.TelaCadastroUsuario import TelaCadastroApp

if __name__ == "__main__":
    TelaCadastroApp().run()