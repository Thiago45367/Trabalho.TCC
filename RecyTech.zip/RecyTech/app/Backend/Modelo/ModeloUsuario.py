import datetime

class ModeloUsuario:
    def __init__(self, id_usuario: int, email: str, senha: str, apelido: str, data_nascimento: datetime):
        self.id_usuario = id_usuario
        self.email = email
        self.senha = senha
        self.apelido = apelido
        self.data_nascimento = data_nascimento