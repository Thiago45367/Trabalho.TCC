# ControleEmp.py
from app.Backend.Modelo.ModeloEmpresa import ModeloEmpresa
from app.Backend.Modelo.ModeloPonto_Coleta import ModeloPontoColeta
from app.Backend.Dao.DaoEmp import DaoEmp
from app.Backend.Dao.DaoEmpPontoColeta import DaoEmpPontoColeta

import requests

class ControleEmp:
    def __init__(self):
        self.dao_emp = DaoEmp()
        self.dao_ponto = DaoEmpPontoColeta()

    # ---------------- EMPRESA ----------------
    def cadastrar_empresa(self, cnpj, nome_Empresa, email_Empresa, senha_Empresa, telefone_Empresa, id_Ponto_Coleta=None):
        empresa = ModeloEmpresa(
            cnpj=cnpj,
            nome_Empresa=nome_Empresa,
            email_Empresa=email_Empresa,
            senha_Empresa=senha_Empresa,
            telefone_Empresa=telefone_Empresa,
            id_Ponto_Coleta=id_Ponto_Coleta
        )
        return self.dao_emp.cadastrar_empresa(empresa)

    def buscar_empresa_por_email(self, email_Empresa):
        """Buscar empresa pelo email"""
        return self.dao_emp.buscar_empresa_por_email(email_Empresa)
    
    def existe_email_empresa(self, email_Empresa):
        """Verifica se já existe uma empresa com este email"""
        return self.dao_emp.existe_email_Empresa(email_Empresa)
    
    def existe_cnpj(self, cnpj):
        """Verifica se já existe uma empresa com este CNPJ"""
        return self.dao_emp.existe_cnpj(cnpj)


    def buscar_lat_lon_por_cep(self, cep: str):
        """Consulta latitude/longitude pelo CEP usando ViaCEP + Nominatim"""
        try:
            # 1. Buscar no ViaCEP
            r = requests.get(f"https://viacep.com.br/ws/{cep}/json/")
            if r.status_code != 200:
                return None, None
            data = r.json()
            if "erro" in data:
                return None, None

            endereco = f"{data['logradouro']}, {data['bairro']}, {data['localidade']}, {data['uf']}, Brasil"

            # 2. Buscar no Nominatim
            url = f"https://nominatim.openstreetmap.org/search?q={endereco}&format=json"
            headers = {"User-Agent": "RecyTechApp/1.0"}
            resp = requests.get(url, headers=headers)

            if resp.status_code == 200 and resp.json():
                dados = resp.json()[0]
                return float(dados["lat"]), float(dados["lon"])
        except:
            pass
        return None, None

    def cadastrar_ponto(self, nome, cep, horario, tipo, remuneracao):
        """Valida CEP, busca lat/lon e salva no banco"""
        lat, lon = self.buscar_lat_lon_por_cep(cep)
        if lat is None or lon is None:
            return False

        ponto = ModeloPontoColeta(
            nome_Ponto=nome,
            cep=cep,
            horario=horario,
            tipo=tipo,
            remuneracao=remuneracao,
            latitude=lat,
            longitude=lon
        )

        self.dao.salvar_ponto(ponto)
        return True

    def listar_pontos(self):
        return self.dao.listar_pontos()
