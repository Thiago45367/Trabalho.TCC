from kivy.app import App
from kivy.uix.boxlayout import BoxLayout
from kivy.lang import Builder
from kivy.uix.behaviors import ButtonBehavior
from kivy.uix.image import Image
from kivy.uix.screenmanager import Screen
from kivy.uix.popup import Popup
from kivy.uix.label import Label
from kivy.uix.button import Button
from kivy.metrics import dp, sp
from kivy.graphics import Color, RoundedRectangle

interface_TelaInicioEmp = '''
<HeaderEmpresa>:
    size_hint_y: None
    height: dp(70)
    padding: dp(10)
    spacing: dp(12)
    canvas.before:
        Color:
            rgba: 0.9, 0.9, 0.9, 1
        Rectangle:
            pos: self.pos
            size: self.size

    FotoPerfil:
        id: foto_perfil
        size_hint: None, None
        size: dp(55), dp(55)
        pos_hint: {"center_y": 0.5}
        source: app.empresa_foto if app.empresa_foto else "app/Frontend/Assets/Foto_Perfil.png"

    Label:
        id: lbl_nome
        text: app.empresa_nome if app.empresa_nome else "Empresa"
        font_size: sp(18)
        color: 0, 0, 0, 1
        halign: "left"
        valign: "middle"
        text_size: self.size
        size_hint_y: None
        height: dp(55)
        pos_hint: {"center_y": 0.5}

<TelaInicialEmpresa>:
    BoxLayout:
        orientation: "vertical"
        padding: 0
        spacing: dp(8)

        canvas.before:
            Color:
                rgba: 1, 1, 0.5, 1
            Rectangle:
                pos: self.pos
                size: self.size

        HeaderEmpresa:
            id: header

        BoxLayout:
            orientation: "vertical"
            padding: dp(8)
            spacing: dp(12)
            size_hint_y: 1

            ScrollView:
                do_scroll_x: False
                BoxLayout:
                    id: feed
                    orientation: "vertical"
                    size_hint_y: None
                    height: self.minimum_height
                    spacing: dp(12)

                    Label:
                        text: "Não há postagens no momento"
                        font_size: sp(18)
                        color: 0,0,0,1
                        halign: "center"
                        valign: "middle"
                        size_hint_y: None
                        height: self.texture_size[1] + dp(20)

        BoxLayout:
            size_hint_y: None
            height: dp(70)
            padding: dp(5)
            spacing: dp(0)
            canvas.before:
                Color:
                    rgba: 0.5, 0.5, 0.5, 1
                Rectangle:
                    pos: self.pos
                    size: self.size

            BoxLayout:
                orientation: "vertical"
                size_hint_x: 1
                IconButton:
                    source: "app/Frontend/Assets/Home.png"
                    size_hint: None, None
                    size: dp(50), dp(50)
                    pos_hint: {"center_x": .5}
                    on_press: root.ir_para_home()
                Label:
                    text: "Início"
                    font_size: sp(13)
                    halign: "center"
                    valign: "middle"
                    text_size: self.size
                    color: 0,0,0,1

            Widget:
                size_hint_x: None
                width: dp(1)
                canvas.before:
                    Color:
                        rgba: 0,0,0,0.3
                    Rectangle:
                        pos: self.pos
                        size: self.size

            BoxLayout:
                orientation: "vertical"
                size_hint_x: 1
                IconButton:
                    source: "app/Frontend/Assets/PontoColeta.png"
                    size_hint: None, None
                    size: dp(50), dp(50)
                    pos_hint: {"center_x": .5}
                    on_press: root.ir_para_reciclar()
                Label:
                    text: "Reciclar"
                    font_size: sp(13)
                    halign: "center"
                    valign: "middle"
                    text_size: self.size
                    color: 0,0,0,1

            Widget:
                size_hint_x: None
                width: dp(1)
                canvas.before:
                    Color:
                        rgba: 0,0,0,0.3
                    Rectangle:
                        pos: self.pos
                        size: self.size

            BoxLayout:
                orientation: "vertical"
                size_hint_x: 1
                IconButton:
                    source: "app/Frontend/Assets/Notificacao.png"
                    size_hint: None, None
                    size: dp(50), dp(50)
                    pos_hint: {"center_x": .5}
                    on_press: root.ir_para_notificacoes()
                Label:
                    text: "Notificações"
                    font_size: sp(13)
                    halign: "center"
                    valign: "middle"
                    text_size: self.size
                    color: 0,0,0,1
'''

Builder.load_string(interface_TelaInicioEmp)

class IconButton(ButtonBehavior, Image):
    pass


class FotoPerfil(ButtonBehavior, Image):
    def on_release(self):
        self.abrir_menu_lateral()

    def abrir_menu_lateral(self):
        app = App.get_running_app()

        # 🔹 Fundo do menu
        menu = BoxLayout(orientation='vertical', padding=dp(12), spacing=dp(6))
        with menu.canvas.before:
            # fundo bege
            Color(0.94, 0.93, 0.85, 0.98)
            self.bg_rect = RoundedRectangle(radius=[0, 0, dp(10), dp(10)], pos=menu.pos, size=menu.size)

            # 🔹 borda esquerda
            Color(0.55, 0.55, 0.55, 1)
            self.left_border = RoundedRectangle(pos=(menu.x, menu.y), size=(dp(6), menu.height))

            # 🔹 borda direita
            Color(0.55, 0.55, 0.55, 1)
            self.right_border = RoundedRectangle(pos=(menu.right - dp(6), menu.y), size=(dp(6), menu.height))

            # 🔹 borda inferior
            Color(0.55, 0.55, 0.55, 1)
            self.bottom_border = RoundedRectangle(pos=(menu.x, menu.y), size=(menu.width, dp(6)))

        def atualizar_bordas(*_):
            # esquerda
            self.left_border.pos = (menu.x, menu.y)
            self.left_border.size = (dp(6), menu.height)
            # direita
            self.right_border.pos = (menu.right - dp(6), menu.y)
            self.right_border.size = (dp(6), menu.height)
            # inferior
            self.bottom_border.pos = (menu.x, menu.y)
            self.bottom_border.size = (menu.width, dp(6))
            # fundo
            self.bg_rect.pos = menu.pos
            self.bg_rect.size = menu.size

        menu.bind(pos=atualizar_bordas, size=atualizar_bordas)

        # 🔹 Linha superior (foto + nome)
        linha_topo = BoxLayout(
            orientation='horizontal',
            spacing=dp(10),
            size_hint_y=None,
            height=dp(55),
            pos_hint={'center_x': 0.5}
        )
        foto = Image(
            source=app.empresa_foto if app.empresa_foto else "app/Frontend/Assets/Foto_Perfil.png",
            size_hint=(None, None),
            size=(dp(50), dp(50))
        )
        nome = Label(
            text=f"[b]{app.empresa_nome if app.empresa_nome else 'Empresa'}[/b]",
            markup=True,
            font_size=sp(17),
            color=(0, 0, 0, 1),
            halign='left',
            valign='middle'
        )
        nome.bind(size=lambda inst, val: setattr(inst, 'text_size', val))
        linha_topo.add_widget(foto)
        linha_topo.add_widget(nome)
        menu.add_widget(linha_topo)

        # Espaço antes do "Sair"
        menu.add_widget(Label(size_hint_y=None, height=dp(15)))

        # 🔹 Linha do botão "Sair"
        linha_sair = BoxLayout(
            orientation='horizontal',
            spacing=dp(10),
            size_hint_y=None,
            height=dp(45),
            padding=[dp(5), dp(5), dp(10), dp(5)]
        )
        icone_sair = Image(
            source="app/Frontend/Assets/Sair.png",
            size_hint=(None, None),
            size=(dp(30), dp(30))
        )
        lbl_sair = Button(
            text="Sair",
            background_normal='',
            background_color=(0, 0, 0, 0),
            color=(0, 0, 0, 1),
            font_size=sp(15),
            halign='left',
            valign='middle'
        )
        lbl_sair.bind(size=lambda inst, val: setattr(inst, 'text_size', val))
        lbl_sair.bind(on_release=self.sair)

        linha_sair.add_widget(icone_sair)
        linha_sair.add_widget(lbl_sair)
        menu.add_widget(linha_sair)

        # 🔹 Popup do menu
        self.popup = Popup(
            title='',
            content=menu,
            size_hint=(0.36, 0.30),
            pos_hint={"x": -0.02, "top": 1.06},
            background_color=(0, 0, 0, 0),
            separator_height=0,
            auto_dismiss=True
        )
        self.popup.open()

    def sair(self, instance):
        if hasattr(self, 'popup'):
            self.popup.dismiss()
        app = App.get_running_app()
        try:
            app.root.current = "TelaLogin"
        except Exception:
            print("⚠️ Erro ao voltar para TelaLogin")


class HeaderEmpresa(BoxLayout):
    pass


class TelaInicialEmpresa(Screen):
    def on_pre_enter(self, *args):
        app = App.get_running_app()
        self.ids.header.ids.lbl_nome.text = app.empresa_nome if app.empresa_nome else "Empresa"

    def ir_para_home(self): ...
    def ir_para_reciclar(self):
        App.get_running_app().root.current = "TelaMapaEmp"
    def ir_para_notificacoes(self):
        App.get_running_app().root.current = "TelaNotificacaoEmp"