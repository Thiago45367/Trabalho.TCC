from kivy.app import App
from kivy.uix.boxlayout import BoxLayout
from kivy.lang import Builder
from kivy.uix.behaviors import ButtonBehavior
from kivy.uix.image import Image
from kivy.uix.screenmanager import Screen

interface_TelaMapaEmp = '''
<TelaMapaEmpresa>:
    BoxLayout:
        orientation: "vertical"

        # ----- CONTEÚDO PRINCIPAL (mapa + opções) -----
        BoxLayout:
            orientation: "vertical"
            size_hint_y: 0.9
            spacing: 0

            # ----- ÁREA DO MAPA -----
            BoxLayout:
                size_hint_y: 0.7
                padding: dp(5)
                canvas.before:
                    Color:
                        rgba: 1, 1, 0.5, 1
                    Rectangle:
                        pos: self.pos
                        size: self.size

                MapView:
                    id: mapa
                    zoom: 12
                    lat: -23.5505
                    lon: -46.6333

            # ----- OPÇÕES (Filtros e SOS) -----
            AnchorLayout:   
                size_hint_y: 0.3
                anchor_y: "center"   # centraliza verticalmente
                canvas.before:
                    Color:
                        rgba: 1, 1, 0.5, 1
                    Rectangle:
                        pos: self.pos
                        size: self.size

                BoxLayout:
                    orientation: "vertical"
                    padding: [10, 0, 10, 0]   # só margem lateral
                    spacing: dp(20)
                    size_hint_y: None
                    height: self.minimum_height
                    anchor_x: "left"

                    # Botão Cadastrar Pontos de Coleta
                BoxLayout:
                    orientation: "horizontal"
                    size_hint_y: None
                    height: dp(30)
                    spacing: dp(10)

                    # Ícone da Prancheta (agora clicável)
                    IconButton:
                        source: "app/Frontend/Assets/Prancheta.png"
                        size_hint: None, None
                        size: dp(30), dp(30)
                        on_press: root.cadastrar_ponto()

                    Button:
                        text: "Filtrar Pontos de Coletas"
                        background_normal: ""  
                        background_color: 0, 0, 0, 0
                        color: 0,0,0,1
                        halign: "left"
                        valign: "middle"
                        text_size: self.size
                        on_press: root.filtrar_pontos()

                    # Botão Ajuda SOS
                    BoxLayout:
                        orientation: "horizontal"
                        size_hint_y: None
                        height: dp(30)
                        spacing: dp(10)
                        Image:
                            source: "app/Frontend/Assets/Help.png"
                            size_hint: None, None
                            size: dp(30), dp(30)
                        Button:
                            text: "Ajuda SOS"
                            background_normal: ""
                            background_color: 0, 0, 0, 0
                            color: 1,0,0,1
                            halign: "left"
                            valign: "middle"
                            text_size: self.size
                            on_press: app.pedir_ajuda()

        # ----- BARRA INFERIOR -----
        BoxLayout:
            size_hint_y: None
            height: dp(70)
            padding: dp(5)
            spacing: dp(0)
            canvas.before:
                Color:
                    rgba: 0.5, 0.5, 0.5, 1
                Rectangle:
                    pos: self.pos
                    size: self.size

            # Aba Início
            BoxLayout:
                orientation: "vertical"
                size_hint_x: 1
                IconButton:
                    source: "app/Frontend/Assets/Home.png"
                    size_hint: None, None
                    size: dp(50), dp(50)
                    pos_hint: {"center_x": .5}
                    on_press: root.ir_para_home()
                Label:
                    text: "Início"
                    font_size: sp(13)
                    halign: "center"
                    valign: "middle"
                    text_size: self.size
                    color: 0,0,0,1

            Widget:
                size_hint_x: None
                width: dp(1)
                canvas.before:
                    Color:
                        rgba: 0,0,0,0.3
                    Rectangle:
                        pos: self.pos
                        size: self.size

            # Aba Reciclar
            BoxLayout:
                orientation: "vertical"
                size_hint_x: 1
                IconButton:
                    source: "app/Frontend/Assets/PontoColeta.png"
                    size_hint: None, None
                    size: dp(50), dp(50)
                    pos_hint: {"center_x": .5}
                    on_press: root.ir_para_reciclar()
                Label:
                    text: "Reciclar"
                    font_size: sp(13)
                    halign: "center"
                    valign: "middle"
                    text_size: self.size
                    color: 0,0,0,1

            Widget:
                size_hint_x: None
                width: dp(1)
                canvas.before:
                    Color:
                        rgba: 0,0,0,0.3
                    Rectangle:
                        pos: self.pos
                        size: self.size

            # Aba Notificações
            BoxLayout:
                orientation: "vertical"
                size_hint_x: 1
                IconButton:
                    source: "app/Frontend/Assets/Notificacao.png"
                    size_hint: None, None
                    size: dp(50), dp(50)
                    pos_hint: {"center_x": .5}
                    on_press: root.ir_para_notificacoes()
                Label:
                    text: "Notificações"
                    font_size: sp(13)
                    halign: "center"
                    valign: "middle"
                    text_size: self.size
                    color: 0,0,0,1

'''


# Carrega o KV
Builder.load_string(interface_TelaMapaEmp)

# Classe para transformar imagem em botão
class IconButton(ButtonBehavior, Image):
    pass

# Imports
from kivy_garden.mapview import MapView, MapMarker
from kivy.clock import Clock
from kivy.uix.label import Label
from kivy.uix.popup import Popup
from kivy.uix.textinput import TextInput
from kivy.uix.button import Button
import requests
import re
from kivy.uix.gridlayout import GridLayout

from app.Backend.Controle.ControleEmp import ControleEmp


# 🔹 Subclasse do MapMarker para abrir popup ao clicar
class PontoMarker(MapMarker):
    def __init__(self, nome_ponto, **kwargs):
        super().__init__(**kwargs)
        self.nome_ponto = nome_ponto

    def on_release(self):
        popup = Popup(
            title="📍 Ponto de Coleta",
            content=Label(text=f"Nome: {self.nome_ponto}", font_size=18),
            size_hint=(0.6, 0.4)
        )
        popup.open()

class TelaMapaEmpresa(Screen):

    def cadastrar_ponto(self):
        """Abre popup para cadastrar ponto de coleta"""
        layout = GridLayout(cols=2, spacing=10, padding=10)

        self.nome_input = TextInput(hint_text="Nome do Ponto")
        self.cep_input = TextInput(hint_text="CEP")
        self.horario_input = TextInput(hint_text="Horário de Funcionamento (HH:MM)")
        self.tipo_input = TextInput(hint_text="Tipo de Coleta")
        self.remuneracao_input = TextInput(hint_text="Remuneração")

        layout.add_widget(Label(text="Nome:"))
        layout.add_widget(self.nome_input)
        layout.add_widget(Label(text="CEP:"))
        layout.add_widget(self.cep_input)
        layout.add_widget(Label(text="Horário:"))
        layout.add_widget(self.horario_input)
        layout.add_widget(Label(text="Tipo:"))
        layout.add_widget(self.tipo_input)
        layout.add_widget(Label(text="Remuneração:"))
        layout.add_widget(self.remuneracao_input)

        btn_salvar = Button(text="Salvar", size_hint_y=None, height=40)
        btn_salvar.bind(on_release=self.salvar_ponto)

        layout.add_widget(btn_salvar)

        self.popup = Popup(
            title="Cadastrar Ponto de Coleta",
            content=layout,
            size_hint=(0.8, 0.7)
        )
        self.popup.open()

    def salvar_ponto(self, instance):
        nome = self.nome_input.text
        cep = self.cep_input.text
        horario = self.horario_input.text
        tipo = self.tipo_input.text
        remuneracao = self.remuneracao_input.text

        controle = ControleEmp()
        sucesso = controle.cadastrar_ponto(nome, cep, horario, tipo, remuneracao)

        if sucesso:
            self.popup.dismiss()
            self.carregar_pontos()
        else:
            self.mostrar_popup_erro("⚠️ Não foi possível localizar o CEP no mapa.")

    def carregar_pontos(self):
        """Recarrega todos os pontos de coleta no mapa"""
        controle = ControleEmp()
        pontos = controle.listar_pontos()

        for ponto in pontos:
            lat = float(ponto.latitude)
            lon = float(ponto.longitude)
            nome = ponto.nome_Ponto

            marcador = MapMarker(lat=lat, lon=lon, source="app/assets/pin.png")
            self.ids.mapview.add_widget(marcador)

    def mostrar_popup_erro(self, mensagem):
        """Exibe popup de erro bonito"""
        conteudo = GridLayout(cols=1, spacing=10, padding=10)
        conteudo.add_widget(Label(text=mensagem))

        btn_fechar = Button(text="Fechar", size_hint_y=None, height=40)
        conteudo.add_widget(btn_fechar)

        popup = Popup(
            title="Erro",
            content=conteudo,
            size_hint=(0.6, 0.4),
            auto_dismiss=False
        )

        btn_fechar.bind(on_release=popup.dismiss)
        popup.open()

    def filtrar_pontos(self):
        print("🔎 Filtrar")

    def pedir_ajuda(self):
        print("🚨 SOS")

    def ir_para_home(self):
        if self.manager:
            self.manager.current = "TelaInicioEmp"

    def ir_para_reciclar(self):
        pass  # já está nessa tela
    
    def ir_para_notificacoes(self):
        if self.manager:
            self.manager.current = "TelaNotificacaoEmp"

class TelaLoginApp(App):
    def build(self):
        return TelaMapaEmpresa()

if __name__ == "__main__":
    TelaLoginApp().run()
