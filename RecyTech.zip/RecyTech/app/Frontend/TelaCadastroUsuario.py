# tela_cadastro.py
from kivy.app import App
from kivy.uix.boxlayout import BoxLayout
from kivy.lang import Builder
from kivy.metrics import dp, sp  # para tamanhos adaptativos

# KV otimizado para telas de celular
interface_TelaCadastroUsuario = f'''
<CadastroScreen>:
    orientation: 'vertical'
    padding: dp(16)
    spacing: dp(12)


    canvas.before:
        Color:
            rgba: 0.2, 0.2, 0.2, 1  # fundo cinza escuro
        Rectangle:
            pos: self.pos
            size: self.size

    # espaço superior
    Widget:
        size_hint_y: 0.1

    # Logo com parte em verde
    Label:
        text: '[b]Recy[color=00FF00]Tech[/color][/b]'
        markup: True
        font_size: sp(32)
        size_hint_y: None
        height: self.texture_size[1] + dp(10)
        halign: 'center'
        valign: 'middle'
        text_size: self.width, None

    # Aba Usuário / Empresa
    BoxLayout:
        size_hint_y: None
        height: dp(44)
        spacing: dp(4)

        ToggleButton:
            text: 'Usuário'
            group: 'tipo'
            state: 'down'
            background_normal: ''
            background_color: 0.2,0.6,0.8,1
            color: 1,1,1,1

        ToggleButton:
            text: 'Empresa'
            group: 'tipo'
            background_normal: ''
            background_color: 0.7,0.7,0.7,1
            color: 0,0,0,1

    # Campos de formulário
    BoxLayout:
        orientation: 'vertical'
        size_hint_y: 0.4
        spacing: dp(8)

        TextInput:
            id: email
            hint_text: 'Digite seu email'
            multiline: False
            size_hint_y: None
            height: dp(48)
            font_size: sp(16)

        TextInput:
            id: senha
            hint_text: 'Senha'
            password: True
            multiline: False
            size_hint_y: None
            height: dp(48)
            font_size: sp(16)

        TextInput:
            id: confirmar
            hint_text: 'Confirmar senha'
            password: True
            multiline: False
            size_hint_y: None
            height: dp(48)
            font_size: sp(16)

    # Botão principal
    Button:
        text: 'CADASTRAR'
        size_hint_y: None
        height: dp(52)
        background_normal: ''
        background_color: 0,0,0,1
        color: 1,1,1,1
        font_size: sp(18)

    # Link para voltar
    Label:
        text: '[u]Voltar para o login[/u]'
        markup: True
        size_hint_y: None
        height: dp(30)
        halign: 'center'
        valign: 'middle'
        text_size: self.width, None
        font_size: sp(14)
'''

Builder.load_string(interface_TelaCadastroUsuario)

class CadastroScreen(BoxLayout):
    pass

class TelaCadastroUsuario(App):
    def build(self):
        return CadastroScreen()

    def voltar_login(self):
        print("Voltando para a tela de login...")

if __name__ == "__main__":
    TelaCadastroUsuario().run()
