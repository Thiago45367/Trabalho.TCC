# tela_cadastro.py
from kivy.app import App
from kivy.uix.boxlayout import BoxLayout
from kivy.lang import Builder
from kivy.config import Config
from kivy.metrics import dp, sp  # dp/sp = tamanhos adaptativos

# Deixa a janela no "formato de celular" para pré-visualizar no PC
Config.set('graphics', 'width', '260')
Config.set('graphics', 'height', '540')

KV = '''
<CadastroScreen>:
    orientation: 'vertical'
    padding: dp(12)
    spacing: dp(6)

    canvas.before:
        Color:
            rgba: 0.5, 0.5, 0.5, 1
        Rectangle:
            pos: self.pos
            size: self.size

    # LOGO
    Label:
        text: '[b]Recy[color=00FF00]Tech[/color][/b]'
        markup: True
        font_size: sp(28)
        size_hint_y: None
        height: self.texture_size[1] + dp(6)
        halign: 'center'
        valign: 'middle'
        text_size: self.width, None

    # Um espacinho para aproximar do painel
    Widget:
        size_hint_y: None
        height: dp(6)

    # PAINEL CENTRAL ESCURO (90% da largura, centralizado)
    AnchorLayout:
        anchor_x: 'center'
        size_hint_y: None
        height: painel.height  # <- AnchorLayout acompanha a altura do painel

        BoxLayout:
            id: painel
            orientation: 'vertical'
            size_hint_x: 0.9
            size_hint_y: None
            height: self.minimum_height  # <- BoxLayout sim tem minimum_height
            padding: dp(10)
            spacing: dp(8)

            canvas.before:
                Color:
                    rgba: 0.2, 0.2, 0.2, 1
                RoundedRectangle:
                    pos: self.pos
                    size: self.size
                    radius: [dp(6)]

            # Abas Usuário/Empresa
            BoxLayout:
                size_hint_y: None
                height: dp(40)
                spacing: dp(8)

                ToggleButton:
                    text: 'Usuário'
                    group: 'tipo'
                    state: 'down'
                    background_normal: ''
                    background_color: 0.12, 0.45, 0.80, 1
                    color: 1,1,1,1
                    font_size: sp(14)

                ToggleButton:
                    text: 'Empresa'
                    group: 'tipo'
                    background_normal: ''
                    background_color: 0.75, 0.75, 0.75, 1
                    color: 0,0,0,1
                    font_size: sp(14)

            # ===== CAMPOS =====

            # Email
            BoxLayout:
                orientation: 'vertical'
                size_hint_y: None
                height: dp(60)
                spacing: dp(2)

                Label:
                    text: 'Email:'
                    color: 1,1,1,1
                    size_hint_y: None
                    height: dp(16)
                    halign: 'left'
                    valign: 'middle'
                    text_size: self.size
                    font_size: sp(12)

                TextInput:
                    id: email
                    hint_text: 'Digite seu Email'
                    multiline: False
                    size_hint_y: None
                    height: dp(36)
                    font_size: sp(14)

            # Senha
            BoxLayout:
                orientation: 'vertical'
                size_hint_y: None
                height: dp(60)
                spacing: dp(2)

                Label:
                    text: 'Senha'
                    color: 1,1,1,1
                    size_hint_y: None
                    height: dp(16)
                    halign: 'left'
                    valign: 'middle'
                    text_size: self.size
                    font_size: sp(12)

                TextInput:
                    id: senha
                    hint_text: 'Senha'
                    password: True
                    multiline: False
                    size_hint_y: None
                    height: dp(36)
                    font_size: sp(14)

            # Confirmar Senha
            BoxLayout:
                orientation: 'vertical'
                size_hint_y: None
                height: dp(60)
                spacing: dp(2)

                Label:
                    text: 'Confirmar Senha'
                    color: 1,1,1,1
                    size_hint_y: None
                    height: dp(16)
                    halign: 'left'
                    valign: 'middle'
                    text_size: self.size
                    font_size: sp(12)

                TextInput:
                    id: confirmar
                    hint_text: 'Confirmar senha'
                    password: True
                    multiline: False
                    size_hint_y: None
                    height: dp(36)
                    font_size: sp(14)

            # Nome de Usuário
            BoxLayout:
                orientation: 'vertical'
                size_hint_y: None
                height: dp(60)
                spacing: dp(2)

                Label:
                    text: 'Nome de Usuário'
                    color: 1,1,1,1
                    size_hint_y: None
                    height: dp(16)
                    halign: 'left'
                    valign: 'middle'
                    text_size: self.size
                    font_size: sp(12)

                TextInput:
                    id: nome_usuario
                    hint_text: 'Seu usuário'
                    multiline: False
                    size_hint_y: None
                    height: dp(36)
                    font_size: sp(14)

            # Data de Nascimento
            BoxLayout:
                orientation: 'vertical'
                size_hint_y: None
                height: dp(60)
                spacing: dp(2)

                Label:
                    text: 'Data de Nascimento'
                    color: 1,1,1,1
                    size_hint_y: None
                    height: dp(16)
                    halign: 'left'
                    valign: 'middle'
                    text_size: self.size
                    font_size: sp(12)

                TextInput:
                    id: data_nascimento
                    hint_text: 'DD/MM/AAAA'
                    multiline: False
                    size_hint_y: None
                    height: dp(36)
                    font_size: sp(14)

    # Botão principal (90% e centralizado)
    AnchorLayout:
        anchor_x: 'center'
        size_hint_y: None
        height: dp(50)

        Button:
            text: '[b]CADASTRAR[/b]'
            markup: True
            size_hint_x: 0.9
            height: dp(48)
            background_normal: ''
            background_color: 0,0,0,1
            color: 1,1,1,1
            font_size: sp(16)

    # Link de voltar
    AnchorLayout:
        anchor_x: 'center'
        size_hint_y: None
        height: dp(28)

        Label:
            text: '[u]Voltar para o login[/u]'
            markup: True
            size_hint_x: 0.9
            halign: 'center'
            valign: 'middle'
            text_size: self.size
            font_size: sp(12)
'''

Builder.load_string(KV)

class CadastroScreen(BoxLayout):
    pass

class TelaCadastroUsuario(App):
    def build(self):
        return CadastroScreen()

if __name__ == "__main__":
    TelaCadastroUsuario().run()
