# tela_cadastro.py
from kivy.app import App
from kivy.uix.boxlayout import BoxLayout
from kivy.lang import Builder
from kivy.config import Config
Config.set('graphics', 'width', '260')
Config.set('graphics', 'height', '540')


# KV em string para evitar criar mais arquivos; mantém a interface separada do main
interface_TelaLogin = '''
<LoginScreen>:
    canvas.before:
        Color:
            rgba: 0.5, 0.5, 0.5, 1  # Cinza médio
        Rectangle:
            pos: self.pos
            size: self.size

    AnchorLayout:
        anchor_x: 'center'
        anchor_y: 'center'

        BoxLayout:
            orientation: 'vertical'
            size_hint: 0.8, None
            height: self.minimum_height
            spacing: dp(20)
            padding: dp(10)

            Label:
                text: "[b]Recy[/b][color=00ff00]Tech[/color]"
                markup: True
                font_size: '32sp'
                halign: 'center'
                size_hint_y: None
                height: self.texture_size[1]

            TextInput:
                hint_text: "Digite seu email"
                size_hint_x: 1   # Largura proporcional
                size_hint_y: None
                height: 40
                pos_hint: {"center_x": 0.5}

            TextInput:
                hint_text: "Senha"
                size_hint_x: 1
                size_hint_y: None
                height: 40
                pos_hint: {"center_x": 0.5}

            Button:
                text: "ENTRAR"
                size_hint_y: None
                height: dp(50)
                background_color: 0, 0, 0, 1
                color: 1, 1, 1, 1


'''

# Carrega a interface KV
Builder.load_string(interface_TelaLogin)

class LoginScreen(BoxLayout):
    pass

class TelaLogin(App):
    def build(self):
        return LoginScreen()

if __name__ == "__main__":
    TelaLogin().run()
