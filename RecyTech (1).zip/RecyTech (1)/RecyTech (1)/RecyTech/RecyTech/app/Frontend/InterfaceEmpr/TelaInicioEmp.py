from kivy.app import App
from kivy.lang import Builder
from kivy.uix.behaviors import ButtonBehavior
from kivy.uix.image import Image
from kivy.uix.screenmanager import Screen
from kivy.uix.popup import Popup
from kivy.uix.label import Label
from kivy.uix.button import Button
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.widget import Widget
from kivy.metrics import dp, sp
from kivy.graphics import Color, RoundedRectangle

interface_TelaInicioEmp = '''
<HeaderEmpresa>:
    size_hint_y: None
    height: dp(55)
    padding: dp(10)
    spacing: dp(10)
    canvas.before:
        Color:
            rgba: 0.9, 0.9, 0.9, 1
        Rectangle:
            pos: self.pos
            size: self.size

    FotoPerfil:
        id: foto_perfil
        size_hint: None, None
        size: dp(38), dp(38)
        source: app.empresa_foto if app.empresa_foto else "app/Frontend/Assets/Foto_Perfil.png"

    # agora é um Button (clicável) em vez de Label
    Button:
        id: lbl_nome
        text: app.empresa_nome if app.empresa_nome else "Empresa"
        markup: True
        font_size: sp(16)
        color: 0,0,0,1
        background_normal: ''
        background_color: 0,0,0,0
        halign: "left"
        valign: "middle"
        text_size: self.size
        on_release: root.ir_para_empresa()

<TelaInicialEmpresa>:
    BoxLayout:
        orientation: "vertical"
        padding: 0
        spacing: dp(8)

        canvas.before:
            Color:
                rgba: 1, 1, 0.5, 1  # fundo amarelo
            Rectangle:
                pos: self.pos
                size: self.size

        # ----- CABEÇALHO -----
        HeaderEmpresa:
            id: header

        # ----- CONTEÚDO -----
        BoxLayout:
            orientation: "vertical"
            padding: dp(8)
            spacing: dp(12)
            size_hint_y: 1

            ScrollView:
                do_scroll_x: False
                BoxLayout:
                    id: feed
                    orientation: "vertical"
                    size_hint_y: None
                    height: self.minimum_height
                    spacing: dp(12)

                    Label:
                        text: "Não há postagens no momento"
                        font_size: sp(18)
                        color: 0,0,0,1
                        halign: "center"
                        valign: "middle"
                        size_hint_y: None
                        height: self.texture_size[1] + dp(20)

        # ----- BARRA INFERIOR -----
        BoxLayout:
            size_hint_y: None
            height: dp(70)
            padding: dp(5)
            spacing: dp(0)
            canvas.before:
                Color:
                    rgba: 0.5, 0.5, 0.5, 1
                Rectangle:
                    pos: self.pos
                    size: self.size

            # Aba Início
            BoxLayout:
                orientation: "vertical"
                size_hint_x: 1
                IconButton:
                    source: "app/Frontend/Assets/Home.png"
                    size_hint: None, None
                    size: dp(50), dp(50)
                    pos_hint: {"center_x": .5}
                    on_press: root.ir_para_home()
                Label:
                    text: "Início"
                    font_size: sp(13)
                    halign: "center"
                    valign: "middle"
                    text_size: self.size
                    color: 0,0,0,1

            Widget:
                size_hint_x: None
                width: dp(1)
                canvas.before:
                    Color:
                        rgba: 0,0,0,0.3
                    Rectangle:
                        pos: self.pos
                        size: self.size

            # Aba Reciclar
            BoxLayout:
                orientation: "vertical"
                size_hint_x: 1
                IconButton:
                    source: "app/Frontend/Assets/PontoColeta.png"
                    size_hint: None, None
                    size: dp(50), dp(50)
                    pos_hint: {"center_x": .5}
                    on_press: root.ir_para_reciclar()
                Label:
                    text: "Reciclar"
                    font_size: sp(13)
                    halign: "center"
                    valign: "middle"
                    text_size: self.size
                    color: 0,0,0,1

            Widget:
                size_hint_x: None
                width: dp(1)
                canvas.before:
                    Color:
                        rgba: 0,0,0,0.3
                    Rectangle:
                        pos: self.pos
                        size: self.size

            # Aba Notificações
            BoxLayout:
                orientation: "vertical"
                size_hint_x: 1
                IconButton:
                    source: "app/Frontend/Assets/Notificacao.png"
                    size_hint: None, None
                    size: dp(50), dp(50)
                    pos_hint: {"center_x": .5}
                    on_press: root.ir_para_notificacoes()
                Label:
                    text: "Notificações"
                    font_size: sp(13)
                    halign: "center"
                    valign: "middle"
                    text_size: self.size
                    color: 0,0,0,1
'''

Builder.load_string(interface_TelaInicioEmp)


class IconButton(ButtonBehavior, Image):
    pass


class FotoPerfil(ButtonBehavior, Image):
    """Ao clicar abre um pequeno card/transparente com o nome (clicável) e apenas 'Sair'."""

    def on_release(self):
        self.abrir_menu_lateral()

    def abrir_menu_lateral(self):
        app = App.get_running_app()

        # container do "card" (conteúdo do popup)
        menu = BoxLayout(orientation='vertical', padding=dp(12), spacing=dp(10), size_hint=(1, 1))

        # desenhar fundo arredondado escuro semi-transparente no próprio menu
        def _draw_bg(instance, *l):
            instance.canvas.before.clear()
            with instance.canvas.before:
                # fundo mais opaco, tom preto/cinza
                Color(0.1, 0.1, 0.1, 0.9)  # quase preto com leve transparência
                RoundedRectangle(pos=instance.pos, size=instance.size, radius=[10])
        menu.bind(pos=_draw_bg, size=_draw_bg)
        _draw_bg(menu)

        # botão com o nome da empresa (clicável) - texto branco
        nome_emp = app.empresa_nome if getattr(app, "empresa_nome", None) else "Empresa"
        btn_nome = Button(
            text=f"[b]{nome_emp}[/b]",
            markup=True,
            size_hint_y=None,
            height=dp(42),
            background_normal='',
            background_color=(0, 0, 0, 0),
            color=(1, 1, 1, 1)
        )

        btn_nome.bind(on_release=lambda inst: self._ir_para_empresa_and_close())
        menu.add_widget(btn_nome)

        # pequeno espaçamento
        menu.add_widget(Widget(size_hint_y=None, height=dp(6)))

        # botão Sair (sem ícone)
        btn_sair = Button(
            text="Sair",
            size_hint_y=None,
            height=dp(44),
            background_normal='',
            background_color=(0, 0, 0, 0),
            color=(1, 1, 1, 1)
        )
        btn_sair.bind(on_release=self._logout_and_close)
        menu.add_widget(btn_sair)

        # montar popup: overlay translúcido + card arredondado (desenhado no menu)
        popup = Popup(
            title='',
            content=menu,
            size_hint=(0.34, 0.2),            # ajuste: largura/altura do card
            pos_hint={"x": 0.02, "top": 0.92},# posiciona perto do canto superior esquerdo (ajuste se necessário)
            background_color=(0, 0, 0, 0),    # remove cor do background do "frame"
            separator_height=0,
            auto_dismiss=True
        )

        # overlay (dim) do Popup — torna o fundo mais transparente/escuro
        try:
            popup.overlay_color = (0, 0, 0, 0.45)
        except Exception:
            # versões mais antigas do Kivy podem não ter overlay_color; não quebra
            pass

        self.popup = popup
        self.popup.open()

    def _ir_para_empresa_and_close(self):
        # Fecha o popup e tenta navegar para uma tela "empresa" conhecida
        if hasattr(self, 'popup'):
            self.popup.dismiss()
        mgr = App.get_running_app().root
        candidate_names = [
            "TelaEmpresa", "TelaPerfil", "TelaCadastroEmpresa", "TelaPerfilEmpresa",
            "Empresa", "TelaEmpresaEmp", "TelaPerfilEmp"
        ]
        for n in candidate_names:
            for s in getattr(mgr, "screens", []):
                if getattr(s, "name", None) == n:
                    mgr.current = n
                    return
        # fallback para TelaInicio se existir
        for s in getattr(mgr, "screens", []):
            if getattr(s, "name", None) == "TelaInicio":
                mgr.current = "TelaInicio"
                return
        print("Tela de empresa não encontrada no ScreenManager (verifique nomes).")

    def _logout_and_close(self, instance):
        # fechar popup e fazer ação de logout (aqui apenas volta pra TelaInicio se existir)
        if hasattr(self, 'popup'):
            self.popup.dismiss()
        app = App.get_running_app()
        mgr = app.root
        for s in getattr(mgr, "screens", []):
            if getattr(s, "name", None) in ("TelaInicio", "Login", "TelaLogin"):
                mgr.current = getattr(s, "name")
                break
        print("Logout acionado")


class HeaderEmpresa(BoxLayout):
    def ir_para_empresa(self):
        # mesmo comportamento do botão dentro do popup: tenta mudar a tela
        mgr = App.get_running_app().root
        candidate_names = [
            "TelaEmpresa", "TelaPerfil", "TelaCadastroEmpresa", "TelaPerfilEmpresa",
            "Empresa", "TelaEmpresaEmp", "TelaPerfilEmp"
        ]
        for n in candidate_names:
            for s in getattr(mgr, "screens", []):
                if getattr(s, "name", None) == n:
                    mgr.current = n
                    return
        for s in getattr(mgr, "screens", []):
            if getattr(s, "name", None) == "TelaInicio":
                mgr.current = "TelaInicio"
                return
        print("Tela de empresa não encontrada no ScreenManager (verifique nomes).")


class TelaInicialEmpresa(Screen):
    def on_pre_enter(self, *args):
        app = App.get_running_app()
        # atualiza o texto do botão do cabeçalho (se o widget existir)
        try:
            self.ids.header.ids.lbl_nome.text = app.empresa_nome if getattr(app, "empresa_nome", None) else "Empresa"
        except Exception:
            pass

    def ir_para_home(self): ...
    
    def ir_para_reciclar(self):
        app = App.get_running_app()
        app.root.current = "TelaMapaEmp"

    def ir_para_notificacoes(self):
        app = App.get_running_app()
        app.root.current = "TelaNotificacaoEmp"